#!/usr/bin/perl
# Win Help �p�ȈՃR���o�[�^ (c)TORO
	use Encode;

	$helpname = 'PPX';
	$src = 'xhelp.txt';
	$lines = 0;
	$myurl = 'http://toro.d.dooo.jp';

	($sec, $min, $hour, $mday, $mon, $copyyear, $wday) = localtime(time);
	$copyyear += 1900;

	$html = $ARGV[0];

	if ( $html ){
		$helpname =~ tr/A-Z/a-z/;
		$dest = $helpname.'help.html';
		$cnt = $helpname.'index.html';
		$words = $helpname.'words.html';
		$commands = $helpname.'cmd.txt';
		$idn = "ID";

		$tag_tail = '<br>';
		$tag_ul = "<hr>";
		$tabmode = '&nbsp;&nbsp;';
	}else{
		$dest = $helpname.'temp.rtf';
		$cnt = $helpname.'.CNT';
		$idn = "";

		$tag_tail = '\par';
		$tag_ul = "\\pard\\brdrb\\brdrs\\par\\pard";
	}

	$indexcnt = 1;
	$anchorcnt = 1000;
#   $anchor{'keyword'} �A���J�[�� ID �̑Ή��\
	$tail = "\n";
# 1 �Ȃ�|�b�v�A�b�v�p
	$popmode = 0;
# 1 �Ȃ�ꗗ�̉��ɏ����R�����g��ۑ�����
	$grouptitlememomode = 0;

#	open(IN, "< PPXVER.H");
#	$version ="?";
#	while (<IN>) {
#		if ( $_ =~ /FileProp_Version[\s\t]*\"([\S]*)\"/ ){
#			$version = $1;
#		}
#	}
#	close(IN);

# ID�����l �ϊ��e�[�u�����쐬
	if ( $html ){
		open(IN, "< $helpname.rh");
		while (<IN>) {
			chop;

			if ( $_ =~ /^#define[\s\t]*([\S]*)[\s\t]*([\S]*)/ ){
				$helpid{$1} = eval($2);
			}
		}
		close(IN);
	}else{ # CustID�`�F�b�N�p�e�[�u�����쐬
		open(IN, "< PPD_CSTD.C");
		while (<IN>) {
			chop;

			while ( $_ =~ /([A-Z]+\_[0-9A-Za-z]+)/g ){
				$CustID{$1} = 1;
			}
		}
		close(IN);
	}

	open(IN, "< $src");
	open(OUT, "> $dest");
	open(OUTCNT, "> $cnt");

	if ( $html ){
		$head = <<_last;
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"><html lang="ja">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style type="text/css"><!--
body { line-height: 150%; word-break: break-word; }
hr { border: solid 1px; }
pre { line-height: 110%; font-size: 105%; white-space: pre-wrap; background-color: #f6f69f; }
img { max-width: 100%; height: auto; }
--></style>
<title>PPx help</title></head>
<body bgcolor="#eeee99" text="#000000" link="#0000CC" vlink="#8800cc" alink="#440088">
_last
		printOut($head);
		$head = <<_last;
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"><html lang="ja">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style type="text/css"><!--
body { line-height: 150%; word-break: break-word; }
--></style>
<title>index</title></head>
<body bgcolor="#eeee99" text="#000000" link="#0000CC" vlink="#8800cc" alink="#440088">
�ڎ� <a href="$words">(����)<br><br></a>
_last
		printIndex($head);
	}else{
		print OUT <<_last;
{\\rtf\\deff1
{\\fonttbl{\\f0\\froman\\fcharset128\\fprq1 ����{\\*\\falt �l�r ����};}
{\\f1\\froman\\fcharset128\\fprq1 �l�r �o�S�V�b�N;}
{\\f2\\froman\\fcharset128\\fprq1 �l�r �o����;}
{\\f3\\fmodern\\fcharset128\\fprq1 �l�r �S�V�b�N;}
{\\f4\\fmodern\\fcharset128\\fprq1 �l�r ����;}
{\\f5\\fnil\\fcharset2\\fprq2 Wingdings;}
{\\f6\\froman\\fcharset0\\fprq2 Century;}
{\\f7\\froman\\fcharset0\\fprq3 Arial;}
{\\f8\\froman\\fcharset0\\fprq3 Courier New;}
{\\f9\\froman\\fcharset0\\fprq3 Times New Roman;}}\\fs22
{\\colortbl;
\\red000\\green000\\blue000;\\red128\\green128\\blue128;\\red175\\green175\\blue175;
\\red255\\green000\\blue000;\\red128\\green000\\blue000;\\red000\\green255\\blue000;
\\red000\\green128\\blue000;\\red000\\green000\\blue255;\\red000\\green000\\blue128;
\\red255\\green255\\blue000;\\red128\\green128\\blue000;\\red000\\green255\\blue255;
\\red000\\green128\\blue128;\\red255\\green000\\blue255;\\red128\\green000\\blue128;
\\red255\\green255\\blue255;}
_last
		print OUTCNT ":Base ".$helpname.".HLP\n";
	}

	while (<IN>) {
		chop;
		$lines++;

		if ( $html ){
			$_ =~ s/\\\{/\{/g;
			$_ =~ s/\\\}/\}/g;
			$_ =~ s/\\\\/\\/g;
			$_ =~ s/<blue>/<b>/g;
			$_ =~ s/<\/blue>/<\/b>/g;
			$_ =~ s/&/&amp;/g;
			$_ =~ s/"/&quot;/g;
			$_ =~ s/< /&lt;/g;
			$_ =~ s/ >/&gt;/g;
		}else{
			if ( $_ =~ /[\!-\<\>-\[\]-z]\\[\!-\<\>-\[\]-z]/ ){
				printf("%d : '\\' not escape\n", $lines);
			}
			$_ =~ s/([\t\s\!-\[\]-z])\{/$1\\\{/g;
			$_ =~ s/^\{/\\{/;
			$_ =~ s/([\t\s\!-\[\]-z])\}/$1\\\}/g;
			$_ =~ s/^\}/\\}/;
			$_ =~ s/<blue>/\{\\cf8 /g;
			$_ =~ s/<\/blue>/\}/g;
			$retry = 1;
			while ( $retry ){
				$retry = 0;
				if ( $_ =~ /<u>/ ){
					if ( $ulcount ){printf("%d : '<u>' over written from %d\n", $lines, $ulcount);}
					$ulcount = $lines;
					$_ =~ s/<u>/{\\ul /;
					$retry = 1;
				}
				if ( $_ =~ /<\/u>/ ){
					if ( !$ulcount ){printf("%d : '<\/u>' over written\n", $lines);}
					$ulcount = 0;
					$_ =~ s/<\/u>/\}/;
					$retry = 1;
				}
				if ( $_ =~ /<b>/ ){
					if ( $boldcount ){printf("%d : '<b>' over written from %d\n", $lines, $boldcount);}
					$boldcount = $lines;
					$_ =~ s/<b>/{\\b /;
					$retry = 1;
				}
				if ( $_ =~ /<\/b>/ ){
					if ( !$boldcount){printf("%d : '<\/b>' over written\n", $lines);}
					$boldcount = 0;
					$_ =~ s/<\/b>/\}/;
					$retry = 1;
				}
				if ( $_ =~ /<i>/ ){
					if ( $itccount ){printf("%d : '<i>' over written from %d\n", $lines, $itccount);}
					$itccount = $lines;
					$_ =~ s/<i>/{\\i /;
					$retry = 1;
				}
				if ( $_ =~ /<\/i>/ ){
					if ( !$itccount ){printf("%d : '<\/i>' over written\n", $lines);}
					$itccount = 0;
					$_ =~ s/<\/i>/\}/;
					$retry = 1;
				}
			}
			$_ =~ s/< /</g;
			$_ =~ s/ >/>/g;
		}

		# �s���̏������@ :tail=\par �{��
		if ( $_ =~ /^\:tail=(.*)/ ){
			$tail = $tag_tail."\n";
			next;
		}
		# :popmode �|�b�v�A�b�v�p�f�[�^�J�n�ʒu
		if ( $_ =~ /:popmode/ ){
			if ( $html ){
				last;
			}
			$popmode = 1;
			next;
		}

		if ( $_ =~ /<grouptitlememo>/ ){
			CheckTermTag();
			$grouptitlememo = $tail;
			$grouptitlememomode = 1;
			next;
		}
		# <grouptitle:title> �O���[�v�ꗗ
		if ( $_ =~ /<grouptitle:([^>]*)>/ ){
			$grouptitlememomode = 0;
			DumpGroupItem();
			$tab = 2000;

			if ( $html ){
				printOut("<a href=\"#$idn$anchorcnt\">$1<\/a>$tail");
				$grouplist .= "$tag_ul$tail\n".
						"<a name=\"$idn$anchorcnt\"><b>$1<\/b><\/a>$tail";
				$groupitem .= "$tag_ul$tail\n"."<b>$1<\/b>$tail";
			}else{
				print OUT "\{\\uldb $1\}\{\\v $anchorcnt\}$tail\n";
				$grouplist .= "$tag_ul$tail\n".
						"#\{\\footnote  $anchorcnt\}\{\\b $1\}$tail$tail\n".
						"\\pard \\li$tab\\fi-$tab\\tx$tab";
				$groupitem .= "$tag_ul$tail\n"."\{\\b $1\}$tail\n";
			}
			$anchorcnt++;
			next;
		}
		# <group:name::title> �O���[�v�A�C�e��(���\�L)
		if ( $_ =~ /<group:(.*)::(.*)>/ ){
			DumpGroupItem();
			$groupitem1 = $1;
			$groupitem2 = $2;
			$groupitemA = "";
			if ( $html ){
				$t = $1;
				$t =~ s/^#//;
				$groupitemA = $wordlist{$t} = $idn.$anchorcnt;
				$anchor{$groupitemA} = $idn.$anchorcnt++;
			}
			next;
		}
		if ( $_ =~ /<groupa:(.*)::(.*)::(.*)>/ ){
			DumpGroupItem();
			$groupitem1 = $1;
			$groupitem2 = $2;
			$groupitemA = $3;
			if ( $html ){ $t = $1; $t =~ s/^#//; $wordlist{$t} = $groupitemA; }
			next;
		}
		# <group:title> �O���[�v�A�C�e��
		if ( $_ =~ /<group:(.*)>/ ){
			DumpGroupItem();
			if ( $1 eq "dump" ){
				printOut("$grouptitlememo$grouplist\n$groupitem\n");
				$grouplist = "";
				$groupitem = "";
				$grouptitlememomode = 0;
				$grouptitlememo = "";
			}else{
				$groupitem1 = $1;
				$groupitem2 = "";
				$groupitemA = "";
			}
			next;
		}
		if ( $_ =~ /<groupa:(.*)::(.*)>/ ){
			DumpGroupItem();
			$groupitem1 = $1;
			$groupitem2 = "";
			$groupitemA = $2;
			if ( $html ){ $t = $1; $t =~ s/^#//; $wordlist{$t} = $groupitemA; }
			next;
		}

		# <a:keyword> �A���J�[����
		while ( $_ =~ /<a:([^>]*)>/ ){
			if ( $anchorset{$1} ){
				printf("%d : '<a:%s>' red(%d)\n", $lines, $1, $anchorset{$1});
			}else{
				$anchorset{$1} = $lines;
			}
			if ( !$anchor{$1} ){
				$anchor{$1} = $idn.$anchorcnt++;
			}
			if ( $html ){
				$_ =~ s/<a:([^>]*)>/<a name="$1"><\/a>/;
			}else{
				$_ =~ s/<a:([^>]*)>/#\{\\footnote  $anchor{$1}\}/;
			}
		}
		# <atk:keyword> �A���J�[&�^�C�g������
		if ( $_ =~ /<atk:([^>]*)>/ ){
			if ( $anchorset{$1} ){
				printf("%d : '<jmpa:%s>' red(%d)\n", $lines, $1, $anchorset{$1});
			}else{
				$anchorset{$1} = $lines;
			}
			if ( !$anchor{$1} ){
				$anchor{$1} = $idn.$anchorcnt++;
			}
			if ( $html ){
				$wordlist{$1} = $1;
				$_ =~ s/<atk:([^>]*)>/<a name="$1"><b>$1<\/b><\/a>/;
			}else{
				$_ =~ s/<atk:([^>]*)>/#\{\\footnote  $anchor{$1}\} K\{\\footnote  $1\}{\\b $1}/;
			}
		}
		# <jmpa:string&keyword> �A���J�[�ւ̃����N
		while ( $_ =~ /<jmpa:([^>:]*)>/ ){
			if ( !$anchor{$1} ){ $anchor{$1} = $idn.$anchorcnt++; }
			if ( $html ){
				$_ =~ s/<jmpa:([^>:]*)>/<a href="#$1">$1<\/a>/;
			}else{
				$_ =~ s/<jmpa:([^>:]*)>/\{\\uldb $1\}\{\\v $anchor{$1}\}/;
			}
		}
		# <jmpa:string:keyword> �A���J�[�ւ̃����N
		while ( $_ =~ /<jmpa:([^>:]*):([^>]*)>/ ){
			if ( !$anchor{$2} ){ $anchor{$2} = $idn.$anchorcnt++; }
			if ( $html ){
				$_ =~ s/<jmpa:([^>:]*):([^>]*)>/<a href="#$2">$1<\/a>/;
			}else{
				$_ =~ s/<jmpa:([^>:]*):([^>]*)>/\{\\uldb $1\}\{\\v $anchor{$2}\}/;
			}
		}
		# <img:filepath> �摜
		if ( $_ =~ /<img:([^>]*)>/ ){
			if ( $html ){
				print OUT "<img src=\"./$1\"><br>";
			}
			next;
		}
		# <myurl>
		$_ =~ s/<myurl>/$myurl/g;
		# <copyyear>
		$_ =~ s/<copyyear>/$copyyear/g;

		# .n=title �V�����u�b�N�Ƃ��̃^�C�g��
		if ( $_ =~ /^\.(\d*)\=(.*)/ ){
			if ( $html ){
				printIndex("<b>$2<\/b><br>\n");
			}else{
				print OUTCNT "$1 $2\n";
			}
			$titlestr[$1] = $2;
			next;
		}
		# .n:title[=id] �V�����y�[�W�Ƃ��̃^�C�g��
		if ( $_ =~ /^\.(\d*)\:(.*)/ ){
			$depth = $1;
			$name = $2;
			if ( $2 =~ /^(.*)\=(.*)/ ){
				$name = $1;
				$id = $2;
				if ( $html ){
					$idn = $2;
					$anchorcnt = 1;
				}
			}else{
				$id = $idn.$anchorcnt++;
			}
			if ( $html ){
				printIndex("<a href=\"$dest#$id\" target=\"main\">$name<\/a><br>\n");
			}else{
				print OUTCNT "$depth $name=$id\n";
			}
			$titlestr[$depth] = $name;
			$title = $titlestr[1];
			for ( $i = 2 ; $i <= $depth ; $i++ ){
				$title = $title." - ".$titlestr[$i];
			}
			if ( $html ){
				$_ = "<a name=\"$id\"></a><a name=\"$name\"></a><h3>$title</h3>";
			}else{
				$_ = '#{\\footnote  '.$id.'}${\\footnote  '.$name.
					'}K{\\footnote  '.$name.'}+{\\footnote 0}\\pard{\\b '.
					$title."}\n\\sl280\\par";
			}
		}
		# +footnote �̘A�ԏ���
		if ( $_ =~ /\+\{\\footnote .*\}/ ){
			$id = sprintf("index:%03d", $indexcnt++);
			if ( $html ){
				$_ = "";
			}else{
				$_ =~ s/\+\{\\footnote [0-9A-Za-z\:]\}/\+\{\\footnote $id\}/g;
			}
		}

		if ( $html ){
			if ( $_ =~ /\\page/ ){
				CheckTermTag();
				$_ =~ s/\\page/<hr>/;
			}
			if ( $_ =~ /<page>/ ){
				CheckTermTag();
				$_ =~ s/<page>/<nocr><hr>/;
			}
			if ( $_ =~ /<(tk|key):([^>]*)/ ){
				$wordlist{$2} = $2;
			}
			$_ =~ s/<key:([^>]*)>/<a name="$1"><\/a>/g;			# <key:keyword>


			$_ =~ s/<tk:([^>]*)>/<a name="$1"><b>$1<\/b><\/a>/g;	# <tk:title>
			while ( $_ =~ /<hid:([^>]*)>/ ){				# <hid:ResourceId>
				$hid = $1;
				if ( $helpid{$hid} ne '' ){ $hid = $helpid{$hid};}
				$_ =~ s/<hid:([^>]*)>/<a name="$hid"><\/a>/;
			}
			if ( $_ =~ /<tb:0>/ ){							# <tb:0> �񋓏I��
				if ( !$listmode ){printf("%d : '<tb:0>' over written\n", $lines);}
				$listmode = 0;
				$_ =~ s/^<tb:0>/<\/dt><\/dl>/g;
				$_ =~ s/<tb:0>/<\/dl>/g;
				$tabcode='&nbsp;&nbsp;';
				$tail="<br>\n";
			}
			if ( $_ =~ /<tb:[^>]*>/ ){						# <tb:n> �񋓊J�n
				if ( $listmode ){printf("%d : '<tb:>' over written from %d\n", $lines, $listmode);}
				$listmode = $lines;
				$_ =~ s/<tb:[^>]*>/<dl compact>/g;
				$tabcode = '</dt><dd>';
				$tail = '';
			}
			if ( $listmode ){
				if ( $_ =~ /\t/ ){
					$_ =~ s/\t/<\/dt><dd>/;		# tab(�ŏ��̂�)
					$_ =~ s/\t/<\/dd><dd>/g;	# tab(�Q�ڈȍ~)
					if ( $_ ne '' ){
						$_ .= "</dd>\n<dt>";
					}else{
						$_ .= "</dt>\n<dt>";
					}
				}else{
					$_ .= "</dt>\n<dt>";
				}
				$_ =~ s/<dl compact><\/dd>/<dl compact>/g;
				$_ =~ s/<dl compact><\/dt>/<dl compact>/g;
			}else{
				$_ =~ s/\t/$tabcode/g;								# tab
			}

			# nothing											# <hr>
			if ( $_ =~ /<pre>/ ){
				if ( $precount ){printf("%d : '<pre>' over written from %d\n", $lines, $precount);}
				$precount = $lines;
				$tail = "\n";
			}
			if ( $_ =~ /<\/pre>/ ){
				if ( !$precount ){printf("%d : '</pre>' over written\n", $lines);}
				$precount = 0;
				$tail = "<br>\n";
			}
			$_ =~ s/<http:([^>]*)>/<a href="http:$1" target="_top">http:$1<\/a>/g;
			$_ =~ s/<https:([^>]*)>/<a href="https:$1" target="_top">https:$1<\/a>/g;
			$_ =~ s/<mailto:([^>]*)>/<a href="mailto:$1"><i>$1<\/i><\/a>/g;
			$_ =~ s/<url:([^>]*)>/<a href="$1">$1<\/a>/g;
			$_ =~ s/<copyright:([^>]*)>/<i>$1<\/i>/g;
			$_ =~ s/<windowskey>/<font face="Wingdings">&#255;<\/font>/g;
		}else{
			$_ =~ s/<key:([^>]*)>/K\{\\footnote  $1\}/g;		# <key:keyword>
			$_ =~ s/<tk:([^>]*)>/K\{\\footnote  $1\}{\\b $1}/g;	# <tk:title>
			$_ =~ s/<hid:([^>]*)>/#\{\\footnote  $1\}/g;	# <hid:ResourceId>

			$_ =~ s/<tb:0>/\\pard /g;							# <tb:0>
			$_ =~ s/<tb:([^>]*)>/\\pard \\li$1\\fi-$1\\tx$1 /g;	# <tb:n>
			$_ =~ s/\t/\\tab /g;								# tab

			$_ =~ s/<hr>/$tag_ul/g;								# <hr>
			$_ =~ s/<pre>/{\\f3 /g;								# <pre>
			$_ =~ s/<\/pre>/ }/g;								# </pre>
			$_ =~ s/<http:([^>]*)>/{\\uldb http:$1}{\\v !ExecFile(http:$1)}/g;
			$_ =~ s/<https:([^>]*)>/{\\uldb https:$1}{\\v !ExecFile(https:$1)}/g;
			$_ =~ s/<mailto:([^>]*)>/{\\uldb $1}{\\v !ExecFile(mailto:$1)}/g;
			$_ =~ s/<url:([^>]*)>/\{\\uldb $1\}\{\\v !ExecFile($1)\}/g;
			$_ =~ s/<copyright:([^>]*)>/\{\\cf8 $1\}/g;
			$_ =~ s/<windowskey>/\{\\f5\\fs30 \\'ff\}/g;
			$_ =~ s/<page>/\\page<nocr>/;

			if ( $_ =~ /<NotID:([^>]*)>/ ){
				$CustID{$1} = 1;
				$_ =~ s/<NotID:([^>]*)>/$1/g;
			}

			foreach ( $_ =~ /([ABEFPSV]|HM|[CKMX][BCETV]?)\_[0-9A-Za-z]+/g ){
				$cid = $&;
				if ( ($cid eq '') | ($cid =~ /(V_H[0-9A-F]|[ACMP]_[A-Z])|XX|xxx|sample|test/) ) {next;}
				if ( !$CustID{$cid} ){
					print "$lines : No custid = $cid\n";
				}
			}
		}

		if ( $grouptitlememomode ){
			$grouptitlememo .= "$_$tail\n";
			next;
		}
		if ( $groupitem1 ne "" ){
			$groupdata .= "$_$tail";
			next;
		}

		if ( $popmode ){
			if ( $_ =~ /^\#\{\\footnote/ ){
				print OUT $1, "\\page\n";
			}
		}
		if ( $_ =~ /<nocr>/ ){ # �s�������̖�����
			$_ =~ s/<nocr>//g;
			printOut("$_\n");
		}else{
			printOut("$_$tail");
		}
	}
	if ( $html ){
		printOut("</body></html>");
		printIndex("</body></html>");

		open(OUTWORDS, "> $words");

		$head = <<_last;
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd"><html lang="ja">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<style type="text/css"><!--
body { line-height: 150%; word-break: break-word; }
--></style>
<title>index</title></head>
<body bgcolor="#eeee99" text="#000000" link="#0000CC" vlink="#8800cc" alink="#440088">
���� <a href="$cnt">(�ڎ�)</a><br><br>
_last
		print OUTWORDS encode('utf8', decode('cp932', $head));

		foreach(sort {$a cmp $b} keys %wordlist){
			print OUTWORDS encode('utf8', decode('cp932', "<a href=\"$dest#$wordlist{$_}\" target=\"main\">$_<\/a><br>\n"));
		}
		print OUTWORDS '</body></html>';
		close(OUTWORDS);

		open(OUTLIST, "> $commands");
		@commandlist = sort @commandlist;
		foreach( @commandlist ){
			print OUTLIST $_;
		}
		close(OUTLIST);
	}else{
		printOut("}");
	}
	close(OUTCNT);
	close(OUT);
	close(IN);

	if ( $html ){
		$online = "../script/ppxwhelp.pl";
		if (-f $online){
			system("perl $online $dest");
		}
	}else{
		system("hcrtf /x ".$helpname.".HPJ"); # /xh �Ȃ����� help ���J��
	}
	while (($name, $value) = each(%anchor)) {
		if ( !$anchorset{$name} ){ printf("anchor $name not defined\n", $name)};
	}
0;

sub DumpGroupItem
{
	CheckTermTag();
	if ( $groupitem1 ne "" ){
		local($footnote);

		if ( $groupitemA ne "" ){
			if ( $anchorset{$groupitemA} ){
				printf("%d : '<a:%s>' red(%d)\n", $lines, $groupitemA, $anchorset{$groupitemA});
			}else{
				$anchorset{$groupitemA} = $lines;
			}
			if ( !$anchor{$groupitemA} ){
				$anchor{$groupitemA} = $idn.$anchorcnt++;
			}
			if ( $html ){
				$ancname = $groupitemA;
			}else{
				$ancname = $anchor{$groupitemA};
			}
		}else{
			$ancname = $idn.$anchorcnt++;
		}

		if ( $html ){
			if ( $groupitem1 =~ /^\#?([\%?\*|\%].*)/ ){
				$commandtext = "$1 $groupitem2\n";
				$commandtext =~ s/\&quot;/\"/g;
				$commandtext =~ s/<\/?i>//g;
				$commandtext =~ s/\s/ ; /;
				push @commandlist, $commandtext;
			}
		}

		if ( $groupitem1 =~ /^\#(.*)/ ){
			if ( $html ){
#				$footnote = "<a name=\"$1\"><\/a>";
#				print $footnote, "\n";
			}else{
				$footnote = "K\{\\footnote  $1\}";
			}
			$groupitem1 = $1;
		}else{
			$footnote = "";
		}
		if ( $groupitem2 eq "" ){
			$groupitem2 = $groupitem1;
			$groupitem1 = "";
		}else{
			if ( $html ){
				$groupitem1 .= "";
			}else{
				$groupitem1 .= "\\tab";
			}
		}
		if ( $groupdata ne "" ){
			if ( $html ){
				$grouplist .= "�E<a href=\"#$ancname\">$groupitem1 $groupitem2<\/a>$tail";
				$groupitem .= "$tag_ul$tail"."<a name=\"$ancname\"><b>$groupitem1 $groupitem2<\/b><\/a>$tail".$groupdata;
			}else{
				$grouplist .= "�E$groupitem1\{\\uldb $groupitem2\}\{\\v $ancname\}$tail\n";
				$groupitem .= "$tag_ul$tail\n"."$footnote#\{\\footnote $ancname\}$groupitem1\{\\b $groupitem2\}$tail".$groupdata;
			}
			$groupdata = "";
		}else{
			$grouplist .= "$footnote�E$groupitem1 $groupitem2$tail";
		}
		$groupitem1 = "";
		$groupitemA = "";
	}
}

sub CheckTermTag
{
	if ( $listmode ){
		printf("%d : '<tb:' not terminate\n", $lines); $listmode = 0;
	}
	if ( $html && ($tail eq "\n") ){
		printf("%d : '<pre>' not terminate\n", $lines); $tail = '<br>\n';
	}
	if ( $precount ){
		printf("%d : '<pre>' not terminate %d\n", $lines, $precount); $precount = 0;
	}
	if ( $ulcount ){
		printf("%d : '<u>' not terminate %d\n", $lines, $ulcount); $ulcount = 0;
	}
	if ( $boldcount ){
		printf("%d : '<b>' not terminate %d\n", $lines, $boldcount); $boldcount = 0;
	}
	if ( $itccount ){
		printf("%d : '<i>' not terminate %d\n", $lines, $itccount); $itccount = 0;
	}
	if ( $listmode ){
		printf("%d : '<tb:>' not terminate %d\n", $lines, $listmode); $listmode = 0;
	}
}

sub printOut
{
	if ( $html ){
		print OUT encode('utf8', decode('cp932', $_[0]));
	}else{
		print OUT $_[0];
	}
}

sub printIndex
{
	print OUTCNT encode('utf8', decode('cp932', $_[0]));
}
