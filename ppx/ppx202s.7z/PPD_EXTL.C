/*-----------------------------------------------------------------------------
	Paper Plane xUI	 commom library						�g���q���O����
-----------------------------------------------------------------------------*/
#define ONPPXDLL // PPCOMMON.H �� DLL ��`�w��
#include "WINAPI.H"
#include "PPX.H"
#include "PPCOMMON.RH"
#include "PPD_DEF.H"
#pragma hdrstop

#ifdef UNICODE
DefineWinAPI(HRESULT, SHLoadIndirectString, (LPCWSTR pszSource, LPWSTR pszOutBuf, UINT cchOutBuf, void **ppvReserved)) = NULL;
#endif

const TCHAR MUIVerbStr[] = T("MUIVerb");
const TCHAR openstr[] = MES_MCOP;
const TCHAR playstr[] = MES_MCPL;
const TCHAR printstr[] = MES_MCPR;
const TCHAR runasV5str[] = MES_MCRK;
const TCHAR runasV6str[] = MES_MCRV;
const TCHAR ExtsChoiseStr[] = T("Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\FileExts\\%s\\UserChoice");
const TCHAR ProgIDstr[] = T("ProgId");
const TCHAR LegacyDisablestr[] = T("LegacyDisable");
const TCHAR PAOstr[] = T("ProgrammaticAccessOnly");
const TCHAR ShellStr[] = T("\\shell");
const TCHAR UnknownExtStr[] = T("Unknown");

HKEY GetExtRegHandle(HKEY keyH, const TCHAR *keyN, const TCHAR *idname, TCHAR *appN)
{
	HKEY hAppShellKey;

	if ( FALSE == GetRegString(keyH, keyN, idname, appN, TSTROFF(MAX_PATH)) ){
		return NULL;
	}

	tstrcat(appN, ShellStr);
	if ( ERROR_SUCCESS != RegOpenKeyEx(HKEY_CLASSES_ROOT, appN, 0, KEY_READ, &hAppShellKey)){
		return NULL;
	}
	return hAppShellKey;
}

// �w��g���q�̃A�N�V�����ꗗ�����j���[�ɓo�^���� -----------------------------
PPXDLL int PPXAPI GetExtentionMenu(HMENU hSubMenu, const TCHAR *ext, PPXMENUDATAINFO *pmdi)
{
	DWORD Bsize; // �o�b�t�@�T�C�Y�w��p

	FILETIME write;
	DWORD keyS;

	TCHAR appN[MAX_PATH]; // �A�v���P�[�V�����̃L�[
	TCHAR keyN[MAX_PATH]; // ���W�X�g���̃L�[����
	TCHAR comN[MAX_PATH]; // ...\\command ������
	TCHAR defN[MAX_PATH]; // �f�t�H���g�̃A�N�V����
	HKEY hAppShellKey = NULL, hCommandKey;

	MENUITEMINFO minfo;

	int cnt = 0;

	minfo.cbSize = sizeof(minfo);
	minfo.fMask = MIIM_STATE | MIIM_TYPE | MIIM_ID;
	minfo.fType = MFT_STRING;
//	minfo.fState = MFS_ENABLED;
	minfo.wID = pmdi->id;

	if ( ext[0] == '.' ){				// �g���q����L�[�����߂� -------------
		// Windows8�ȍ~
		wsprintf(keyN, ExtsChoiseStr, ext);
		if ( (hAppShellKey = GetExtRegHandle(HKEY_CURRENT_USER, keyN, ProgIDstr, appN)) == NULL ){
			// �]��
			if ( (hAppShellKey = GetExtRegHandle(HKEY_CLASSES_ROOT, ext, NilStr, appN)) == NULL ){
				// �S��
				if ( (hAppShellKey = GetExtRegHandle(HKEY_CLASSES_ROOT, WildCard_All, NilStr, appN)) == NULL ){
					tstrcpy(appN, UnknownExtStr); // �Y������
				}
			}
		}
	}else if ( ext[0] != '\0' ){
		tstrcpy(appN, ext);
	}else{
		tstrcpy(appN, UnknownExtStr); // �g���q����
	}
	if ( hAppShellKey == NULL ){
		tstrcat(appN, ShellStr);
										// �A�v���P�[�V�����̃V�F�� -----------
		if ( ERROR_SUCCESS != RegOpenKeyEx(HKEY_CLASSES_ROOT, appN, 0, KEY_READ, &hAppShellKey)){
			goto nomenuitem;
		}
	}

	Bsize = sizeof(defN);
	defN[0] = '\0';
	RegQueryValueEx(hAppShellKey, NilStr, NULL, NULL, (LPBYTE)defN, &Bsize);
	if ( defN[0] == '\0' ) tstrcpy(defN, ShellVerb_open);	// �f�t�H���g�̎w�肪����

	for ( ; ; cnt++ ){					// �ݒ�����o�� ---------------------
		keyS = TSIZEOF(keyN);
		if ( ERROR_SUCCESS != RegEnumKeyEx(hAppShellKey, cnt, keyN, &keyS, NULL, NULL, NULL, &write) ){
			break;
		}

		if ( ERROR_SUCCESS == RegOpenKeyEx(hAppShellKey, keyN, 0, KEY_READ, &hCommandKey) ){
			Bsize = sizeof(appN);
			if ( ERROR_SUCCESS == RegQueryValueEx(hCommandKey, LegacyDisablestr, NULL, NULL, NULL, &Bsize) ){
				RegCloseKey(hCommandKey);
				continue;
			}
			RegCloseKey(hCommandKey);
		}

		// key��printto(�w��v�����^�Ɉ��)�ȊO  && shell\key name\command ���J����Ȃ�o�^
		tstrcpy(comN, keyN);
		tstrcat(comN, T("\\command"));
		if ( (tstricmp(keyN, T("printto")) != 0) && (ERROR_SUCCESS == RegOpenKeyEx(hAppShellKey, comN, 0, KEY_READ, &hCommandKey)) ){
			RegCloseKey(hCommandKey);
			minfo.dwTypeData = keyN;
							// �f�t�H���g�͑����ɂ���
			minfo.fState = (tstricmp(defN, keyN) == 0) ?
					(MFS_ENABLED | MFS_DEFAULT) : MFS_ENABLED;

			if ( pmdi->th.top != MAX32 ){
				HKEY hAppItemKey;

				RegOpenKeyEx(hAppShellKey, keyN, 0, KEY_READ, &hAppItemKey);
				// �\���p�̕����񂪂���Ύ擾
				Bsize = sizeof(appN);
				appN[0] = '\0';
#ifdef UNICODE
				RegQueryValueEx(hAppItemKey, MUIVerbStr, NULL, NULL, (LPBYTE)appN, &Bsize);
				if ( appN[0] == '\0' ){
#endif
					Bsize = sizeof(appN);
					RegQueryValueEx(hAppItemKey, NilStr, NULL, NULL, (LPBYTE)appN, &Bsize);
#ifdef UNICODE
				}
#endif
				if ( appN[0] == '@' ){
#ifdef UNICODE
					if ( DSHLoadIndirectString == NULL ){
						GETDLLPROC(GetModuleHandle(T("shlwapi.dll")), SHLoadIndirectString);
					}
					if ( DSHLoadIndirectString != NULL ){
						DSHLoadIndirectString(appN, appN, MAX_PATH, NULL);
					}
#else
					appN[0] = '\0';
#endif
				}

				if ( appN[0] == '\0' ){ // �\�������񂪖����Ƃ��B
					Bsize = sizeof(appN);
					if ( RegQueryValueEx(hAppItemKey, PAOstr, NULL, NULL, (LPBYTE)appN, &Bsize) == ERROR_SUCCESS ){
						// ProgrammaticAccessOnly ������̂ŕ\�����Ȃ�
						RegCloseKey(hAppItemKey);
						continue;
					}

					if ( !tstricmp(keyN, ShellVerb_open) ){
						minfo.dwTypeData = (TCHAR *)MessageText(openstr);
					}else if ( !tstricmp(keyN, T("print")) ){
						minfo.dwTypeData = (TCHAR *)MessageText(printstr);
					}else if ( !tstricmp(keyN, T("play")) ){
						minfo.dwTypeData = (TCHAR *)MessageText(playstr);
					}else if ( !tstrcmp(keyN, T("runas")) ){
						minfo.dwTypeData = (TCHAR *)MessageText(
								(WinType >= WINTYPE_VISTA) ?
								runasV6str : runasV5str);
					}
				}else{
					minfo.dwTypeData = appN;
				}
				RegCloseKey(hAppItemKey);
				ThAddString(&pmdi->th, keyN);
			}
			InsertMenuItem(hSubMenu, 0xffff, TRUE, &minfo);
			minfo.wID++;
		}
	}
	RegCloseKey(hAppShellKey);
	if ( pmdi->id == minfo.wID ) goto nomenuitem;
	pmdi->id = minfo.wID;
	return cnt;

nomenuitem:
	minfo.dwTypeData = T("*open");
	minfo.fState = MFS_ENABLED;
	InsertMenuItem(hSubMenu, 0xffff, TRUE, &minfo);
	pmdi->id++;
	return 0;
}

// 1.20 ���_�Ŗ��g�p
PPXDLL int PPXAPI PP_GetContextMenu(HMENU hSubMenu, const TCHAR *ext, DWORD *ID)
{
	PPXMENUDATAINFO pmdi;
	int result;

	pmdi.th.top = MAX32;
	pmdi.id = *ID;
	result = GetExtentionMenu(hSubMenu, ext, &pmdi);
	*ID = pmdi.id;
	return result;
}
