﻿//!*script

PPx.report("\r\n* sample_arg.js ("+ PPx.ScriptEngineName + " " + PPx.ScriptEngineVersion + ")\r\n");

var arg = PPx.Arguments;
var len = arg.length; // PPx.Arguments.length も可
var list;
if ( len == 0 ){
	PPx.report("no parameter\r\n");
}else{
	PPx.report("Sample 1: " + PPx.Argument(-1) + "\r\n");
	// 手動列挙の例1
	list = "Sample 2: ";
	for ( var i = 0; i < len ; i++ ){
		list = list + PPx.Argument(i) + ", "; // (WSH/V8/QuickJS兼用)PPx.Argument(i), (WSH限定)PPx.Arguments(i)
	}
	PPx.report(list + "\r\n");

	// 手動列挙の例2
	list = "Sample 3: ";
	for (var v = PPx.Arguments; !v.atEnd(); v.moveNext() ){
		list = list + v.value + ", "; // (WSH/V8/QuickJS兼用)v.value, (WSH限定)v.Item (V8限定)v.Item()
	}
	PPx.report(list + "\r\n");

	// 自動列挙の例1 (V8/QuickJS 限定, Chakraでは結果が空欄)
	// PPx.report("Sample 4: " + Array.from(PPx.Arguments).join(',') + "\r\n");

	// 自動列挙の例2 (V8/QuickJS 限定)
	// list = "Sample 5: ";
	// for ( var v of PPx.Arguments ){
	//     list = list + v + ", ";
	// }
	// PPx.report(list + "\r\n");
}
