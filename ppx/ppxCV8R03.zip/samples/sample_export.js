//!*script

export function test(num)
{
	return num * 123;
}
