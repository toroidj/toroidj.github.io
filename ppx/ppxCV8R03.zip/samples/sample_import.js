//!*script
import * as exmodule from "./sample_export.js";

PPx.Echo("10 * 123 = " + exmodule.test(10));
