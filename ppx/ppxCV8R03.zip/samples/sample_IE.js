//!*script
var IE = PPx.CreateObject("InternetExplorer.Application");
IE.Visible = true;
IE.Navigate("http://toro.d.dooo.jp/");
