﻿//!*script
// JScript / JScript(Chakra) / V8 / QuickJS 兼用

PPx.Include('./sample_i_source.js');
PPx.report("\r\nstatic 10 * 123 = " + test(10) + "\r\n");
