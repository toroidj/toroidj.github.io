//!*script
// QuickJS / V8 �p

export function test(num)
{
	return num * 123;
}
