﻿//!*script
// マークエントリのすべての情報を順番に表示する

// ディレクトリ情報
// (兼用)PPx.Pane.Tab
PPx.report(
	"Script Engine: " + PPx.ScriptEngineName + "\r\n" +
	"ScriptFullName: " + PPx.ScriptFullName + "\r\n" +
	"ScriptName: " + PPx.ScriptName + "\r\n" +
	"WindowIDName: " + PPx.WindowIDName + "\r\n" +
	"EntryIndex: " + PPx.EntryIndex + "\r\n" +
	"EntryDisplayTop: " + PPx.EntryDisplayTop + "\r\n" +
	"EntryDisplayX: " + PPx.EntryDisplayX + "\r\n" +
	"EntryDisplayY: " + PPx.EntryDisplayY + "\r\n" +
	"WindowDirection: " + PPx.WindowDirection + "\r\n" +
	"Pane index-Tab index: " + PPx.Pane.index + "-" + PPx.Pane.Tab.index + "\r\n" +
	"PaneLock: " + PPx.Pane.Tab.Lock + "\r\n\r\n"
);

// カーソルを動かす例
if ( PPx.EntryFirstMark == 0 ){
	PPx.Echo("マークはありません");
}else{
	do {
		PPx.Echo("EntryIndex: " + PPx.EntryIndex + "\n" +
			"EntryName: " + PPx.EntryName + "\n" +
			"EntryComment: " + PPx.EntryComment + "\n" +
			"EntryAttributes: " + PPx.EntryAttributes + "\n" +
			"EntrySize: " + PPx.EntrySize + "\n" +
			"EntryMark: " + PPx.EntryMark
		);
	}while( PPx.EntryNextMark != 0 );
}

// カーソルを動かすことなく表示する例
// マークがないときはカーソル上のエントリを対象とする
// マークの有無を判定するときは FirstMark が 0 であるかで判定する。
// (WSH)items.DateXXX (V8)items.DateXXX.ToString()
var items = PPx.Entry;
if ( items.FirstMark == 0 ){ PPx.Echo("マークはありません"); }
for ( ;; ){
	PPx.report("Index: " + items.index + "\r\n" +
		"Name: " + items.Name + "\r\n" +
		"ShortName: " + items.ShortName + "\r\n" +
		"Attributes: " + items.Attributes + "\r\n" +
		"Size: " + items.Size + "\r\n" +
		"Created: " + items.DateCreated + "\r\n" +
		"LastModified: " + items.DateLastModified + "\r\n" +
		"LastAccessed: " + items.DateLastAccessed + "\r\n" +
		"State :" + items.State + "\r\n" +
		"Color :" + items.ExtColor + "\r\n" +
		"Comment: " + items.Comment + "\r\n" +
		"Comment 1: " + items.GetComment(1) + "\r\n" +
		"Comment 2: " + items.GetComment(2) + "\r\n" +
		"Comment 3: " + items.GetComment(3) + "\r\n\r\n"
	);
	if ( items.NextMark == 0 ) break;
}
