//!*script

PPx.linemessage(PPx.ScriptEngineName);
var arg = PPx.Arguments;
var len = arg.length; // PPx.Arguments.length も可
var list;
if ( len == 0 ){
	PPx.Echo("no parameter");
}else{
	PPx.Echo(PPx.Argument(-1));
	// 手動列挙の例1
	list = "Sample1: ";
	for ( var i = 0; i < len ; i++ ){
		list = list + PPx.Argument(i) + ", "; // (兼用)PPx.Argument(i), (WSH限定)PPx.Arguments(i)
	}
	PPx.Echo(list);

	// 手動列挙の例2
	list = "Sample2: ";
	for (var v = PPx.Arguments; !v.atEnd(); v.moveNext() ){
		list = list + v.value + ", "; // (兼用)v.value, (WSH限定)v.Item (V8限定)v.Item()
	}
	PPx.Echo(list);
/*
	// 自動列挙の例1 (V8限定, Chakraでは結果が空欄)
	PPx.Echo("Sample 3: " + Array.from(PPx.Arguments).join(','));

	// 自動列挙の例2 (V8限定)
	list = "Sample4: ";
	for ( var v of PPx.Arguments ){
		list = list + v + ", ";
	}

	PPx.Echo(list);
*/
}
