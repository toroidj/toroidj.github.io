/*-----------------------------------------------------------------------------
	Paper Plane xUI	 Virtual File System				�` List File ���� �`
-----------------------------------------------------------------------------*/
#define ONVFSDLL		// VFS.H �� DLL export �w��
#include "WINAPI.H"
#include <shlobj.h>
#include "PPX.H"
#include "PPD_DEF.H"
#include "VFS.H"
#include "VFS_STRU.H"
#include "VFS_FF.H"
#pragma hdrstop

const TCHAR TypeName_ListFile[] = T("List");

/*-----------------------------------------------------------------------------
	��s���擾����
-----------------------------------------------------------------------------*/
TCHAR *FixListOneLine(FF_LFILE *list)
{
	TCHAR *ptr, *bottom;
	const TCHAR *maxptr = list->maxptr;

	bottom = ptr = list->readptr;
	while ( ptr < maxptr ){
		bottom = ptr = SkipSpaceAndFix(ptr);
		if ( *ptr == '\0' ){		// ��s?
			ptr++;
			continue;
		}
		if ( *ptr == ';'){
			ptr++;
			while( *ptr ){
				if ( (*ptr == '\r') || (*ptr == '\n') ){
					ptr++;
					break;
				}
				ptr++;
			}
			continue;
		}
		while( *ptr ){		// �R�����g�̏���
			if ( (*ptr == '\r') || (*ptr == '\n') ){
				*ptr++ = '\0';
				if ( (*ptr == '\r') || (*ptr == '\n') ) ptr++;
				break;
			}
			ptr++;
		}
		if ( *bottom != '\0' ) break;
	}
	list->readptr = ptr;
	return bottom;
}
// �s���󔒂������Q -----------------------------------------------------------
void ReadFileTime(TCHAR **ptr, FILETIME *ft)
{
	ft->dwHighDateTime = (DWORD)GetNumber((const TCHAR **)ptr);
	if ( SkipSpace((const TCHAR **)ptr) == '.' ) (*ptr)++;
	ft->dwLowDateTime = (DWORD)GetNumber((const TCHAR **)ptr);
}

TCHAR *GetLFname(TCHAR **src, TCHAR *dest, int size)
{
	TCHAR *srcptr, *maxdest, *resultptr = NULL, chr;

	srcptr = *src + 1;
	maxdest = dest + size - 1;
	for (;;){
		chr = *srcptr;
		if ( chr == '\0' ) break;
		srcptr++;
		if ( chr == '\"' ) break;
		if ( dest < maxdest ) *dest++ = chr;
	}
	*dest = '\0';
	if ( dest == maxdest ){
		resultptr = *src + 1;
		if ( *(srcptr - 1) == '\"' ) *(srcptr - 1) = '\0';
	}
	*src = srcptr;
	return resultptr;
}

BOOL GetListLine(FF_LFILE *list, WIN32_FIND_DATA *findfile)
{
	TCHAR *line;

	if ( list->readptr >= list->maxptr ) goto EOL;
	line = FixListOneLine(list);

	memset(findfile, 0, (BYTE *)findfile->cFileName - (BYTE *)findfile + sizeof(TCHAR));
	// findfile->cFileName[0] = '\0'; // ���ŏ������ς�
	findfile->cAlternateFileName[0] = '\0';
	list->extra.mask = 0;
	list->longname = NULL;
	list->comment = NULL;

	if ( SkipSpace((const TCHAR **)&line) != '\"' ){ // " �Ȃ��c�t�@�C�����̂�
		DWORD atr;
		TCHAR *dest, *destmax;
		const TCHAR *lineptr;

		if ( *line == '\0' ) goto EOL;
		atr = GetFileAttributesL(line);
		if ( atr != BADATTR ){
			findfile->dwFileAttributes = atr | FILE_ATTRIBUTEX_NODETAIL;
		}

		dest = findfile->cFileName;
		destmax = dest + MAX_PATH - 1;
		lineptr = line;
		while ( *lineptr != '\0' ){
			*dest++ = *lineptr++;
			if ( dest >= destmax ){
				list->longname = line;
				findfile->cFileName[0] = FINDOPTION_LONGNAME;
				tstplimcpy(findfile->cFileName + 1, line, MAX_PATH);
				break;
			}
		}
		*dest = '\0';
	}else{	// " ����c�e�푮���L��
		TCHAR c;

		// �t�@�C����
		list->longname = GetLFname(&line, findfile->cFileName, MAX_PATH);
		if ( list->longname != NULL ) findfile->cFileName[0] = '>';
		if ( SkipSpace((const TCHAR **)&line) != ',' ){
			DWORD attr;

			attr = GetFileAttributesL(findfile->cFileName);
			if ( attr != BADATTR ) findfile->dwFileAttributes = attr;
			return TRUE;
		}
		// ,["�Z���t�@�C����"]
		line++;
		c = SkipSpace((const TCHAR **)&line);
		if ( c == '\"' ){	// �P�� " �c SFN
			GetLFname(&line, findfile->cAlternateFileName, 13);
			c = SkipSpace((const TCHAR **)&line);
			if ( c != ',' ) return TRUE;
			line++;
		}
		// �e��ǉ���� x:xxx
		while ( *line != '\0' ){
			c = SkipSpace((const TCHAR **)&line);
			if ( *(line + 1) != ':' ) break;
			line += 2;
			switch (c){	// A:x	����
				case 'A':
					findfile->dwFileAttributes |=
						GetNumber((const TCHAR **)&line) &
						~(FILE_ATTRIBUTEX_LF_MARK | B26/*FILE_ATTRIBUTEX_LF_COMMENT�A�݊��p*/ );
					break;
				case 'C':	// C:x.x �쐬����
					ReadFileTime(&line, &findfile->ftCreationTime);
					break;
				case 'L':	// L:x.x �ŏI�A�N�Z�X����
					ReadFileTime(&line, &findfile->ftLastAccessTime);
					break;
				case 'W':	// W:x.x �X�V����
					ReadFileTime(&line, &findfile->ftLastWriteTime);
					break;
				case 'S':	// S:x.x �T�C�Y
					findfile->nFileSizeHigh = (DWORD)GetNumber((const TCHAR **)&line);
					if ( SkipSpace((const TCHAR **)&line) == '.' ) line++;
					findfile->nFileSizeLow = (DWORD)GetNumber((const TCHAR **)&line);
					break;
				case 'R':	// R:n.n dwReserved0/1
					findfile->dwReserved0 = (DWORD)GetNumber((const TCHAR **)&line);
					if ( SkipSpace((const TCHAR **)&line) == '.' ) line++;
					findfile->dwReserved1 = (DWORD)GetNumber((const TCHAR **)&line);
					break;
				case 'M':	// M:0|1|-1 �}�[�N
					if ( *line == '1' ){
						setflag(findfile->dwFileAttributes, FILE_ATTRIBUTEX_LF_MARK);
						setflag(list->extra.mask, FODE_MARK_ON);
					}else if ( *line == '0' ){
						setflag(findfile->dwFileAttributes, FILE_ATTRIBUTEX_EXTRA);
						setflag(list->extra.mask, FODE_MARK_OFF);
					}else if ( *line == '-' ){
						line++;
						setflag(findfile->dwFileAttributes, FILE_ATTRIBUTEX_EXTRA);
						setflag(list->extra.mask, FODE_MARK_TOGGLE);
					}
					while ( Isdigit(*line) ) line++;
					break;
				case 'H':	// H:n �n�C���C�g
					setflag(findfile->dwFileAttributes, FILE_ATTRIBUTEX_EXTRA);
					setflag(list->extra.mask, FODE_HIGHLIGHT);
					list->extra.highlight = (BYTE)GetNumber((const TCHAR **)&line);
					break;
				case 'X':	// X:n �g���q�F
					setflag(findfile->dwFileAttributes, FILE_ATTRIBUTEX_EXTRA);
					setflag(list->extra.mask, FODE_COLOR);
					list->extra.extC = (COLORREF)GetNumber((const TCHAR **)&line);
					break;
				case 'O':	// On:... �g�����(�J�����C���f�b�N�X)
					setflag(findfile->dwFileAttributes, FILE_ATTRIBUTEX_EXTRA);
					setflag(list->extra.mask, FODE_EXTDATA);
					break;
				case 'T': {	// T:�c �R�����g
					UTCHAR c1, c2;

					c1 = *(line + 0);
					c2 = *(line + 1);
					if ( ((c1 == '\"') && (c2 != '\"') && (c2 >= ' '))
						|| ((c1 != ',') && (c1 >= ' ')) ){
						setflag(findfile->dwFileAttributes, FILE_ATTRIBUTEX_EXTRA);
						setflag(list->extra.mask, FODE_COMMENT);
						list->comment = line;
					}
				}
					// default ��
				default:	// ����`�c��͏I��
					line = T("");
			}
			if ( SkipSpace((const TCHAR **)&line) != ',' ) break;
			line++;
		}
	}
	return TRUE;
EOL:
	SetLastError(ERROR_NO_MORE_FILES);
	return FALSE;
}

ERRORCODE InitFindFirstListFile(VFSFINDFIRST *VFF, const TCHAR *Fname, WIN32_FIND_DATA *findfile)
{
	ERRORCODE result;

	result = LoadTextData(Fname, &VFF->v.LFILE.mem, &VFF->v.LFILE.readptr, &VFF->v.LFILE.maxptr, 0);
	if ( result == NO_ERROR ){
		VFF->v.LFILE.type = VFSDT_LFILE_TYPE_PARENT;
		VFF->v.LFILE.base = NilStr;
		VFF->v.LFILE.search = NilStr;
		VFF->v.LFILE.sort = NilStr;
		VFF->v.LFILE.view = NilStr;
		VFF->v.LFILE.extra.size = sizeof(FOD_EXTRADATA);
		VFF->mode = VFSDT_LFILE;
		VFF->TypeName = TypeName_ListFile;
		SetDummydir(findfile, T("."));
		findfile->dwReserved0 = 0;
		findfile->dwReserved1 = 0;

		while ( VFF->v.LFILE.readptr < (VFF->v.LFILE.maxptr - 2) ){
			const TCHAR *line;

			if ( *VFF->v.LFILE.readptr != ';' ) break;
			VFF->v.LFILE.readptr++;
			line = FixListOneLine(&VFF->v.LFILE);
			if ( memcmp(line, T("Base="), 5 * sizeof(TCHAR)) == 0 ){
				VFF->v.LFILE.base = line + 5;
			}
			if ( memcmp(line, T("Search="), 7 * sizeof(TCHAR)) == 0 ){
				VFF->v.LFILE.search = line + 7;
			}
			if ( memcmp(line, T("Sort="), 5 * sizeof(TCHAR)) == 0 ){
				VFF->v.LFILE.sort = line + 5;
			}
			if ( memcmp(line, T("View="), 5 * sizeof(TCHAR)) == 0 ){
				VFF->v.LFILE.view = line + 5;
			}
			if ( memcmp(line, T("Error="), 6 * sizeof(TCHAR)) == 0 ){
				line += 6;
				result = (ERRORCODE)GetNumber((const TCHAR **)&line);
			}
			if ( memcmp(line, T("Option=directory"), 16 * sizeof(TCHAR)) == 0 ){
				setflag(findfile->dwFileAttributes, FILE_ATTRIBUTEX_FOLDER);
			}
			if ( memcmp(line, T("Option=archive"), 14 * sizeof(TCHAR)) == 0 ){
				setflag(findfile->dwFileAttributes, FILE_ATTRIBUTEX_FOLDER | FILE_ATTRIBUTE_ARCHIVE);
			}
		}
	}
	return result;
}
