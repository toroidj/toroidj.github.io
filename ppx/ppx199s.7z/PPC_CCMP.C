/*-----------------------------------------------------------------------------
	Paper Plane cUI		��r�}�[�N
-----------------------------------------------------------------------------*/
#include "WINAPI.H"
#include "PPX.H"
#include "VFS.H"
#include "PPC_STRU.H"
#include "PPC_FUNC.H"
#include "FATTIME.H"
#include "sha.h"
#pragma hdrstop

BOOL cmplog = 0; // �s��v���ڂ̃��O�����i�J�����j

INT_PTR CALLBACK CompareDetailDlgBox(HWND hDlg, UINT iMsg, WPARAM wParam, LPARAM lParam);
#define CompareDetailDialog(hWnd, param) PPxDialogBoxParam(hInst, MAKEINTRESOURCE(IDD_CMARK), hWnd, CompareDetailDlgBox, (LPARAM)param)

typedef struct {
	const TCHAR *name;
	DWORD mode;
} COMPAREMENUSTRUCT;

#define ATTR_FILE	0x0700
#define ATTR_DIR	(0x1700 | CMPSUBDIR)
COMPAREMENUSTRUCT CompareMenu[] = {
	{MES_CMPN, ATTR_FILE | CMP_NEW},
	{MES_CMPW, ATTR_FILE | CMP_NEWONLY},
	{MES_CMPT, ATTR_FILE | CMP_TIME},
	{MES_CMPE, ATTR_FILE | CMP_EXIST},
	{MES_CMPX, ATTR_DIR  | CMP_EXIST},
	{MES_CMPS, ATTR_FILE | CMP_SIZE},
	{MES_CMPL, ATTR_FILE | CMP_LARGE},
	{MES_CMPA, ATTR_FILE | CMP_SAMESIZETIME},
	{MES_CMPB, ATTR_DIR  | CMP_BINARY},
	{MES_CMP1, ATTR_DIR  | CMP_SHA1},
	{MES_CMPF, ATTR_FILE | CMP_EXIST | CMPWITHOUT_EXT},
	{MES_CMPQ, ATTR_FILE | CMP_SIZEONLY},
	{NULL, 0}
};

#define DETAILMENU_ITEMS 13
const TCHAR *CompareDetailMenu[DETAILMENU_ITEMS] = {
	// CMP_2
	MES_CMPN, MES_CMPT, MES_CMPE, MES_CMPS, MES_CMPL, // 1�`
	MES_CMPA, MES_CMPB, MES_CMPI, MES_CMPW, MES_CMP1, // 5�`
	// CMPWITHOUT_EXT
	MES_CMPF,
	// CMP_1
	MES_CMPZ, MES_CMPM,
}; // 11�`

const int CompareDetailIndex[DETAILMENU_ITEMS] = {
	CMP_NEW, CMP_TIME, CMP_EXIST, CMP_SIZE, CMP_LARGE,
	CMP_SAMESIZETIME, CMP_BINARY, CMP_SIZEONLY, CMP_NEWONLY, CMP_SHA1,
	CMP_EXIST | CMPWITHOUT_EXT,
	CMP_1SIZE, CMP_1COMMENT
};

#define CPI_INTERVAL 1000
typedef struct {
	DWORD tick;
	ENTRYINDEX in;
	PPC_APPINFO *cinfo;
	TCHAR *path;
} COMPPROGINFO;

struct COMPAREBINARYSTRUCT {
	COMPPROGINFO *cpi;
	char *srcbuf, *destbuf;
	SIZE32_T bufsize;
	int mode, subdir;
};

const TCHAR StrCCMP[] = MES_CCMP;

void Result_Match(PPC_APPINFO *cinfo, int count)
{
	TCHAR text[256];

	if ( count < 0 ){
		tstrcpy(text, MessageText(MES_CCMC));
	}else if ( count == 0 ){
		tstrcpy(text, MessageText(StrEENF));
	}else{
		wsprintf(text, T("%s: %d"), MessageText(StrCCMP), count);
	}
	SetPopMsg(cinfo, POPMSG_MSG, text);
}

void Result_Compare(PPC_APPINFO *cinfo, int count)
{

	StopPopMsg(cinfo, PMF_PROGRESS);
	Result_Match(cinfo, count);
	ActionInfo(cinfo->info.hWnd, &cinfo->info, AJI_COMPLETE, T("compare")); // �ʒm
}

//---------------------------------------------------------- �ꗗ���𑗐M����
BOOL PPcCompareSend(PPC_APPINFO *cinfo, COMPAREMARKPACKET *cmp, HWND PairHWnd)
{
	HANDLE	hFile;
	BOOL	result;
	DWORD	qsize, wsize;

	hFile = CreateFileL(cmp->filename, GENERIC_WRITE,
			FILE_SHARE_WRITE | FILE_SHARE_READ, NULL, CREATE_ALWAYS,
			FILE_ATTRIBUTE_TEMPORARY | FILE_FLAG_SEQUENTIAL_SCAN, NULL);
	if ( hFile == INVALID_HANDLE_VALUE ) return FALSE;

	qsize = sizeof(ENTRYCELL) * cinfo->e.cellDataMax;
	result = WriteFile(hFile, cinfo->e.CELLDATA.p, qsize, &wsize, NULL);

	if ( IsTrue(result) && (qsize != wsize) ){
		SetLastError(ERROR_DISK_FULL);
		result = FALSE;
	}

	CloseHandle(hFile);

	if ( IsTrue(result) ){
		COPYDATASTRUCT copydata;

		cmp->DirType = cinfo->e.Dtype.mode;
		cmp->LoadCounter = cinfo->LoadCounter;
		copydata.dwData = 'O';
		copydata.cbData = sizeof(COMPAREMARKPACKET);
		copydata.lpData = cmp;
		SendMessage(PairHWnd, WM_COPYDATA,
					(WPARAM)cinfo->info.hWnd, (LPARAM)&copydata);
	}
	return result;
}


BOOL USEFASTCALL CompareProgress(COMPPROGINFO *cpi)
{
	TCHAR buf[32 + VFPS];
	BOOL result;

	wsprintf(buf, T("%d/%d %s"), cpi->in, cpi->cinfo->e.cellIMax, cpi->path);
	SetPopMsg(cpi->cinfo, POPMSG_PROGRESSBUSYMSG, buf);
	UpdateWindow_Part(cpi->cinfo->info.hWnd);
	if ( IsTrue( result = ReadDirBreakCheck(cpi->cinfo) ) ){
		SetPopMsg(cpi->cinfo, POPMSG_MSG, MES_BRAK);
		cpi->in = cpi->cinfo->e.cellIMax;
	}
	if ( GetAsyncKeyState(VK_PAUSE) & KEYSTATE_FULLPUSH ){
		if ( PMessageBox(cpi->cinfo->info.hWnd, MES_AbortCheck, MES_TFCP, MB_QYES) == IDOK ){
			SetPopMsg(cpi->cinfo, POPMSG_MSG, MES_BRAK);
			cpi->in = cpi->cinfo->e.cellIMax;
			result = TRUE;
		}
	}
	return result;
}

/*----------------------------------------------------------
	NO_ERROR			��v����
	ERROR_INVALID_DATA	��v���Ȃ�����
	���̑�				��r���ɃG���[�����������i���̎��_�ŏI���j
*/
ERRORCODE PPcCompareExistDirMain(COMPPROGINFO *cpi, const TCHAR *srcpath, WIN32_FIND_DATA *cellN, const TCHAR *destpath)
{
	TCHAR srcname[VFPS], destname[VFPS];
	ERRORCODE result;
	HANDLE hFFsrc, hFFdest;
								// �f�B���N�g������ ---------------------------
	WIN32_FIND_DATA ffsrc;
	WIN32_FIND_DATA ffdest;
	TCHAR tempname[VFPS];
	DWORD filecount = 0;

	VFSFullPath(srcname, cellN->cFileName, srcpath);
	VFSFullPath(destname, cellN->cFileName, destpath);
	CatPath(tempname, destname, T("*"));
								// ���Α��̃t�@�C�������Z�o
	hFFdest = FindFirstFileL(tempname, &ffdest);
	if ( hFFdest == INVALID_HANDLE_VALUE ){
		return ERROR_INVALID_DATA;
	}
	for ( ; ; ){
		if ( !IsRelativeDir(ffdest.cFileName) ){
			filecount++;

			if ( (filecount & 0x3f) == 0 ){
				DWORD nowtick;
				nowtick = GetTickCount();

				if ( (nowtick - cpi->tick) > CPI_INTERVAL ){
					cpi->tick = nowtick;
					cpi->path = destname;
					if ( IsTrue(CompareProgress(cpi)) ){
						FindClose(hFFdest);
						return ERROR_CANCELLED;
					}
				}
			}
		}
		if ( FALSE == FindNextFile(hFFdest, &ffdest) ) break;
	}
	FindClose(hFFdest);
								// �����瑤�̃t�@�C�������������߁A��r
	CatPath(tempname, srcname, T("*"));
	hFFsrc = FindFirstFileL(tempname, &ffsrc);
	if ( hFFsrc == INVALID_HANDLE_VALUE ){
		return ERROR_INVALID_DATA;
	}
	result = NO_ERROR;
	for ( ; ; ){
		DWORD attr;

		if ( !IsRelativeDir(ffsrc.cFileName) ){
			filecount--;
			CatPath(tempname, destname, ffsrc.cFileName);
			attr = GetFileAttributesL(tempname);
			if ( attr == BADATTR ){
				if ( cmplog ){
					XMessage(NULL, NULL, XM_DbgLOG, T("not match %s"), tempname);
				}
				result = ERROR_INVALID_DATA;
				break;
			}
			if ( attr & FILE_ATTRIBUTE_DIRECTORY ){
				if ( !(ffsrc.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) ){
					if ( cmplog ){
						XMessage(NULL, NULL, XM_DbgLOG, T("not match %s"), tempname);
					}
					result = ERROR_INVALID_DATA;
					break;
				}
				result = PPcCompareExistDirMain(cpi, srcname, &ffsrc, destname);
				if ( result != NO_ERROR ) break;
			}

			if ( (filecount & 0x3f) == 0 ){
				DWORD nowtick;
				nowtick = GetTickCount();

				if ( (nowtick - cpi->tick) > CPI_INTERVAL ){
					cpi->tick = nowtick;
					cpi->path = srcname;
					if ( IsTrue(CompareProgress(cpi)) ){
						result = ERROR_CANCELLED;
						break;
					}
				}
			}
		}

		if ( FALSE == FindNextFile(hFFsrc, &ffsrc) ){
			if ( filecount ) result = ERROR_INVALID_DATA;
			break;
		}
	}
	FindClose(hFFsrc);
	return result;
}

ERRORCODE PPcCompareSizeTimeDirMain(COMPPROGINFO *cpi, const TCHAR *srcpath, WIN32_FIND_DATA *cellN, const TCHAR *destpath)
{
	TCHAR srcname[VFPS], destname[VFPS];
	ERRORCODE result;
	HANDLE hFFsrc, hFFdest;
								// �f�B���N�g������ ---------------------------
	WIN32_FIND_DATA ffsrc;
	WIN32_FIND_DATA ffdest;
	TCHAR tempname[VFPS];
	DWORD filecount = 0;

	VFSFullPath(srcname, cellN->cFileName, srcpath);
	VFSFullPath(destname, cellN->cFileName, destpath);
	CatPath(tempname, destname, T("*"));
								// ���Α��̃t�@�C�������Z�o
	hFFdest = FindFirstFileL(tempname, &ffdest);
	if ( hFFdest == INVALID_HANDLE_VALUE ){
		return ERROR_INVALID_DATA;
	}
	for ( ; ; ){
		if ( !IsRelativeDir(ffdest.cFileName) ){
			filecount++;

			if ( (filecount & 0x3f) == 0 ){
				DWORD nowtick;
				nowtick = GetTickCount();

				if ( (nowtick - cpi->tick) > CPI_INTERVAL ){
					cpi->tick = nowtick;
					cpi->path = destname;
					if ( IsTrue(CompareProgress(cpi)) ){
						FindClose(hFFdest);
						return ERROR_CANCELLED;
					}
				}
			}
		}
		if ( FALSE == FindNextFile(hFFdest, &ffdest) ) break;
	}
	FindClose(hFFdest);
								// �����瑤�̃t�@�C�������������߁A��r
	CatPath(tempname, srcname, T("*"));
	hFFsrc = FindFirstFileL(tempname, &ffsrc);
	if ( hFFsrc == INVALID_HANDLE_VALUE ){
		return ERROR_INVALID_DATA;
	}
	result = NO_ERROR;
	for ( ; ; ){
		if ( !IsRelativeDir(ffsrc.cFileName) ){
			FILE_STAT_DATA ffd;
			filecount--;
			CatPath(tempname, destname, ffsrc.cFileName);


			if ( GetFileSTAT(tempname, &ffd) == FALSE ){
				result = ERROR_INVALID_DATA;
				break;
			}

			if ( ffd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY ){
				if ( !(ffsrc.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) ){
					result = ERROR_INVALID_DATA;
					break;
				}
				result = PPcCompareSizeTimeDirMain(cpi, srcname, &ffsrc, destname);
				if ( result != NO_ERROR ) break;
			}

			if ( FuzzyCompareFileTime(&ffsrc.ftLastWriteTime,
					&ffd.ftLastWriteTime) ||
				(ffsrc.nFileSizeHigh != ffd.nFileSizeHigh) ||
				(ffsrc.nFileSizeLow != ffd.nFileSizeLow ) ){
				result = ERROR_INVALID_DATA;
			}

			if ( (filecount & 0x3f) == 0 ){
				DWORD nowtick;
				nowtick = GetTickCount();

				if ( (nowtick - cpi->tick) > CPI_INTERVAL ){
					cpi->tick = nowtick;
					cpi->path = srcname;
					if ( IsTrue(CompareProgress(cpi)) ){
						result = ERROR_CANCELLED;
						break;
					}
				}
			}
		}

		if ( FALSE == FindNextFile(hFFsrc, &ffsrc) ){
			if ( filecount ) result = ERROR_INVALID_DATA;
			break;
		}
	}
	FindClose(hFFsrc);
	return result;
}

BOOL IsBreakCompare(COMPPROGINFO *cpi)
{
	DWORD nowtick;

	nowtick = GetTickCount();
	if ( (nowtick - cpi->tick) > CPI_INTERVAL ){
		cpi->tick = nowtick;
		if ( IsTrue(CompareProgress(cpi)) ) return TRUE;
	}
	return FALSE;
}

ERRORCODE PPcCompareBinary(struct COMPAREBINARYSTRUCT *cbs, const TCHAR *srcpath, WIN32_FIND_DATA *cellN, const TCHAR *destpath, WIN32_FIND_DATA *cellp)
{
	TCHAR srcname[VFPS], destname[VFPS];
	HANDLE hSrc, hDest;
	ERRORCODE result;
	DWORD srcsize, destsize;
								// �f�B���N�g������ ---------------------------
	if ( cellN->dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY ){
		if ( (cbs->subdir) && (cellp->dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) ){
			HANDLE hFFsrc, hFFdest;
			WIN32_FIND_DATA ffsrc;
			WIN32_FIND_DATA ffdest;
			TCHAR tempname[VFPS];
			DWORD filecount = 0;

			VFSFullPath(srcname, cellN->cFileName, srcpath);
			VFSFullPath(destname, cellN->cFileName, destpath);
			CatPath(tempname, destname, T("*"));
								// ���Α��̃t�@�C�������Z�o
			hFFdest = FindFirstFileL(tempname, &ffdest);
			if ( hFFdest == INVALID_HANDLE_VALUE ){
				return ERROR_INVALID_DATA;
			}
			cbs->cpi->path = destname;
			for ( ; ; ){
				if ( !IsRelativeDir(ffdest.cFileName) ) filecount++;

				if ( (filecount & 0x3f) == 0 ){
					if ( IsBreakCompare(cbs->cpi) ){
						FindClose(hFFdest);
						return ERROR_CANCELLED;
					}
				}
				if ( FALSE == FindNextFile(hFFdest, &ffdest) ) break;
			}
			FindClose(hFFdest);
								// �����瑤�̃t�@�C�������������߁A��r
			CatPath(tempname, srcname, T("*"));
			hFFsrc = FindFirstFileL(tempname, &ffsrc);
			if ( hFFsrc == INVALID_HANDLE_VALUE ){
				return ERROR_INVALID_DATA;
			}
			result = NO_ERROR;
			for ( ; ; ){
				if ( !IsRelativeDir(ffsrc.cFileName) ){
					filecount--;
					CatPath(tempname, destname, ffsrc.cFileName);
					if ( FALSE == GetFileSTAT(tempname, &ffdest) ){
						result = ERROR_INVALID_DATA;
						break;
					}
					result = PPcCompareBinary(cbs,
							srcname, &ffsrc, destname, &ffdest);
					if ( result != NO_ERROR ) break;
				}

				if ( FALSE == FindNextFile(hFFsrc, &ffsrc) ){
					if ( filecount ) result = ERROR_INVALID_DATA;
					break;
				}
			}
			FindClose(hFFsrc);
			return result;
		}
		return ERROR_INVALID_DATA;
	}

	if ( cellp->dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY ){
		return ERROR_INVALID_DATA;
	}
								// �t�@�C���T�C�Y�������H
	if ( cellN->nFileSizeHigh != cellp->nFileSizeHigh ){
		return ERROR_INVALID_DATA;
	}
	if ( cellN->nFileSizeLow != cellp->nFileSizeLow ){
		return ERROR_INVALID_DATA;
	}
								// �C���[�W�`�F�b�N ---------------------------
	VFSFullPath(srcname, cellN->cFileName, srcpath);
	VFSFullPath(destname, cellN->cFileName, destpath);
	hSrc = CreateFileL(srcname, GENERIC_READ,
			FILE_SHARE_READ | FILE_SHARE_WRITE,
			NULL, OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, NULL);
	if ( hSrc == INVALID_HANDLE_VALUE ){
		return GetLastError();
	}
	hDest = CreateFileL(destname, GENERIC_READ,
			FILE_SHARE_READ | FILE_SHARE_WRITE,
			NULL, OPEN_EXISTING, FILE_FLAG_SEQUENTIAL_SCAN, NULL);
	if ( hDest == INVALID_HANDLE_VALUE ){
		result = GetLastError();
		CloseHandle(hSrc);
		return result;
	}
	result = NO_ERROR;
	cbs->cpi->path = cellN->cFileName; // srcname,destname ��SHA���Ŕj�󂳂��
	if ( cbs->mode == CMP_BINARY ){ // CMP_BINARY
		for ( ; ; ){
			if ( FALSE == ReadFile(hSrc, cbs->srcbuf, cbs->bufsize, &srcsize, NULL) ){
				result = GetLastError();
				break;
			}
			if ( srcsize == 0 ) break;

			if ( FALSE == ReadFile(hDest, cbs->destbuf, cbs->bufsize, &destsize, NULL) ){
				result = GetLastError();
				break;
			}
			if ( (srcsize != destsize) ||
				memcmp(cbs->srcbuf, cbs->destbuf, srcsize) ){
				result = ERROR_INVALID_DATA;
				break;
			}

			if ( IsBreakCompare(cbs->cpi) ){
				result = ERROR_CANCELLED;
				break;
			}
		}
	}else{ // CMP_SHA1
		SHA1Context sha1;

		SHA1Reset(&sha1);
		for ( ; ; ){
			if ( FALSE == ReadFile(hSrc, cbs->srcbuf, cbs->bufsize, &srcsize, NULL) ){
				result = GetLastError();
				break;
			}
			if ( srcsize == 0 ) break;
			SHA1Input(&sha1, (uint8_t *)cbs->srcbuf, srcsize);

			if ( IsBreakCompare(cbs->cpi) ){
				result = ERROR_CANCELLED;
				break;
			}
		}
		SHA1Result(&sha1, (uint8_t *)&srcname);

		if ( result == NO_ERROR ){
			SHA1Reset(&sha1);
			for ( ; ; ){
				if ( FALSE == ReadFile(hDest, cbs->destbuf, cbs->bufsize, &destsize, NULL) ){
					result = GetLastError();
					break;
				}
				if ( destsize == 0 ) break;
				SHA1Input(&sha1, (uint8_t *)cbs->destbuf, destsize);

				if ( IsBreakCompare(cbs->cpi) ){
					result = ERROR_CANCELLED;
					break;
				}
			}
			SHA1Result(&sha1, (uint8_t *)&destname);
			if ( result == NO_ERROR ){
				if ( memcmp(srcname, destname, SHA1HashSize) ){
					result = ERROR_INVALID_DATA;
				}
			}
		}
	}
	CloseHandle(hSrc);
	CloseHandle(hDest);
	return result;
}

ERRORCODE PPcCompareBinaryMain(COMPPROGINFO *cpi, int mode, int subdir, WIN32_FIND_DATA *cellN, const TCHAR *destpath, WIN32_FIND_DATA *cellp)
{
	struct COMPAREBINARYSTRUCT cbs;
	ERRORCODE result;

	GetAsyncKeyState(VK_PAUSE); // �ǂݎ̂�(�ŉ���bit�΍�)
	cbs.cpi = cpi;
					// 2000�ȍ~:1Mbytes / 9x,NT4:256kbytes
	cbs.bufsize = (OSver.dwMajorVersion >= 5) ? (1 * MB) : (256 * KB);
	cbs.srcbuf = PPcHeapAlloc(cbs.bufsize);
	cbs.destbuf = PPcHeapAlloc(cbs.bufsize);
	cbs.mode = mode;
	cbs.subdir = subdir;
	result = PPcCompareBinary(&cbs, cpi->cinfo->RealPath, cellN, destpath, cellp);
	PPcHeapFree(cbs.srcbuf);
	PPcHeapFree(cbs.destbuf);
	return result;
}

void MessageMatchEntry(HWND hWnd, HWND hPairWnd, DWORD PairLoadCounter, TCHAR *filename)
{
	COPYDATASTRUCT copydata;

	copydata.dwData = TMAKELPARAM('O' + 0x100, PairLoadCounter);
	copydata.cbData = TSTRSIZE32(filename);
	copydata.lpData = filename;
	SendMessage(hPairWnd, WM_COPYDATA, (WPARAM)hWnd, (LPARAM)&copydata);
}

//------------------------------------------------------------------ ��r���C��
ERRORCODE PPcCompareMain(PPC_APPINFO *cinfo, HWND hPairWnd, COMPAREMARKPACKET *cmp)
{
	ENTRYCELL *paircell = NULL, *pairbase;
	int mode;
	int cmp_match = 0, cmp_total = 0;
	ENTRYCOUNT cells;			// ����̃Z����
	DWORD sizeL;		// �t�@�C���̑傫��
	TCHAR pairpath[VFPS];
	DWORD PairLoadCounter;
	DWORD dirmask, unmarkmask;
	int subdir;
	BOOL SimpleDir; // �t�@�C�������f�B���N�g�����ň�ӂ��ǂ���(���x�œK���p)
	ERRORCODE result;
	COMPPROGINFO cpi;

	mode = cmp->mode;
	PairLoadCounter = cmp->LoadCounter;
	cinfo->MarkMask = (mode >> CMPMARKSHIFT) & CMPMARKMASK;
	subdir = (mode & CMPSUBDIR) ? FILE_ATTRIBUTE_DIRECTORY : 0;
	dirmask = cinfo->MarkMask & FILE_ATTRIBUTE_DIRECTORY;
	unmarkmask = (cinfo->MarkMask | subdir) ^ CMPMARKMASK;
	mode &= CMPTYPEMASK | CMPDOWN;

	if ( (mode == (CMP_BINARY | CMPDOWN)) ||
		 (mode == (CMP_SIZEONLY | CMPDOWN)) ||
		 (mode == (CMP_SHA1 | CMPDOWN)) /* ||
		 ((mode == (CMP_SAMESIZETIME | CMPDOWN)) && (subdir != 0)) */
	){
		Repaint(cinfo);
		return NO_ERROR;	// �ς�
	}
	if ( (((mode == CMP_EXIST) || (mode == CMP_SAMESIZETIME)) && (subdir != 0)) ||
		 (mode == CMP_BINARY) || (mode == CMP_SHA1) ){
		DWORD attr;

		PPcOldPath((INT_PTR)hPairWnd, MAX32, pairpath);
		attr = GetFileAttributesL(pairpath);
		if ( (attr == BADATTR) || !(attr & FILE_ATTRIBUTE_DIRECTORY) ){
			return ERROR_BAD_DEV_TYPE;
		}
	}
										// File Open --------------------------
	result = LoadFileImage(cmp->filename, 0,
			(char **)&paircell, &sizeL, LFI_ALWAYSLIMITLESS);
	if ( result != NO_ERROR ) return result;

	PPxCommonCommand(cinfo->info.hWnd, JOBSTATE_COMPARE, K_ADDJOBTASK);
	if ( (mode == CMP_BINARY) || (mode == CMP_SHA1) ){
		SetPopMsg(cinfo, POPMSG_PROGRESSBUSYMSG, MES_SCMP);
		UpdateWindow_Part(cinfo->info.hWnd);
	}else{
		StopPopMsg(cinfo, PMF_STOP);
	}
										// ��r���� ---------------------------
	cpi.cinfo = cinfo;
	cpi.tick = GetTickCount();
	cells = sizeL / sizeof(ENTRYCELL);
	pairbase = paircell;
	// ���Ύw�������
	while ( cells && IsRelativeDir(pairbase->f.cFileName) ){
		pairbase++;
		cells--;
	}
	{
		ENTRYINDEX in;

		for ( in = 0 ; in < cells ; in++ ){
			if ( pairbase[in].state < ECS_NORMAL ){
				// SysMsg��Deleted�͔�r�ΏۊO�ɂ���
				pairbase[in].f.cFileName[0] = '\0';
			}
		}
	}
	SimpleDir = (cinfo->e.Dtype.mode == VFSDT_PATH) && (cmp->DirType == VFSDT_PATH);
										// ��r���[�v -------------------------

	if ( mode & CMPWITHOUT_EXT ){
		ENTRYINDEX ip;
		int extoffset;

		for ( cpi.in = 0 ; cpi.in < cinfo->e.cellIMax ; cpi.in++ ){
			TCHAR *nowname, *pairname;
			ENTRYCELL *cellN, *cellp;

			cellN = &CEL(cpi.in);
			if ( cellN->state < ECS_NORMAL ) continue; // SysMsg��Deleted�͂���
			if ( cellN->attr & (ECA_PARENT | ECA_THIS) ) continue;
			if ( cellN->f.dwFileAttributes & unmarkmask ) continue;

			nowname = FindLastEntryPoint(cellN->f.cFileName);
			extoffset = cellN->ext - (nowname - cellN->f.cFileName);
			cellp = pairbase;
			for ( ip = cells ; ip ; ip--, cellp++ ){
				DWORD nowtick;
														// �}�[�N�ΏۊO�����H
				if ( cellp->f.dwFileAttributes & unmarkmask ) continue;

				nowtick = GetTickCount();
				if ( (nowtick - cpi.tick) > CPI_INTERVAL ){
					cpi.tick = nowtick;
					cpi.path = cellN->f.cFileName;
					if ( IsTrue(CompareProgress(&cpi)) ) break;
				}
				cmp_total++;
				pairname = FindLastEntryPoint(cellp->f.cFileName);
				if ( tstrnicmp(nowname, pairname, extoffset) ) continue; // ���O�s��v
				// ���O�����s��v
				if ( (pairname[extoffset] != '\0') && // �����łȂ�
					  ((pairname[extoffset] != '.') || // �g���q�łȂ�
					   (tstrchr(pairname + extoffset + 1, '.') != NULL)) ){
					continue;
				}
				if ( cellp->f.dwFileAttributes & dirmask ){
							// ������t�@�C���ŁA�������f�B���N�g���Ȃ�ΏۊO
					if ( (cellp->f.dwFileAttributes ^
						cellN->f.dwFileAttributes) & FILE_ATTRIBUTE_DIRECTORY){
						continue;
					}
				}
				cmp_match++;
				CellMark(cinfo, cpi.in, MARK_CHECK);
			}
		}
	}else if ( mode != CMP_SIZEONLY ){
		ENTRYINDEX ip;

		for ( cpi.in = 0 ; cpi.in < cinfo->e.cellIMax ; cpi.in++ ){
			TCHAR *nowname, *pairname;
			ENTRYCELL *cellN, *cellp;

			cellN = &CEL(cpi.in);
			if ( cellN->state < ECS_NORMAL ) continue; // SysMsg��Deleted�͂���
			if ( cellN->attr & (ECA_PARENT | ECA_THIS) ) continue;
			if ( cellN->f.dwFileAttributes & unmarkmask ) continue;

			nowname = FindLastEntryPoint(cellN->f.cFileName);
			cellp = pairbase;
			for ( ip = cells ; ip ; ip--, cellp++ ){
				DWORD nowtick;
														// �}�[�N�ΏۊO�����H
				if ( cellp->f.dwFileAttributes & unmarkmask ) continue;

				nowtick = GetTickCount();
				if ( (nowtick - cpi.tick) > CPI_INTERVAL ){
					cpi.tick = nowtick;
					cpi.path = cellN->f.cFileName;
					if ( IsTrue(CompareProgress(&cpi)) ) break;
				}
				cmp_total++;
				pairname = FindLastEntryPoint(cellp->f.cFileName);
				if ( tstricmp(nowname, pairname) ) continue;

				if ( cellp->f.dwFileAttributes & dirmask ){
							// ������t�@�C���ŁA�������f�B���N�g���Ȃ�ΏۊO
					if ( (cellp->f.dwFileAttributes ^
						cellN->f.dwFileAttributes) & FILE_ATTRIBUTE_DIRECTORY){
						continue;
					}
				}

				switch(mode){
					case CMP_NEW:				// old(���Α� new file)
					case CMP_TIME:				// old(���Α� TimeStamp)
						if ( FuzzyCompareFileTime(&cellN->f.ftLastWriteTime,
								&cellp->f.ftLastWriteTime) < 0 ){
							cmp_match++;
							CellMark(cinfo, cpi.in, MARK_CHECK);
						}
						break;
					case CMP_NEW | CMPDOWN:	// new(���ݑ� new file)
					case CMP_TIME | CMPDOWN:	// new(���ݑ� TimeStamp)
						if ( FuzzyCompareFileTime(&cellN->f.ftLastWriteTime,
								&cellp->f.ftLastWriteTime) > 0 ){
							cmp_match++;
							CellMark(cinfo, cpi.in, MARK_CHECK);
						}else if ( cmplog ){
							XMessage(NULL, NULL, XM_DbgLOG, T("not match %s"), cellN->f.cFileName);
						}
						break;

					case CMP_EXIST | CMPDOWN:	// Exist(���ݑ� Exist)
						if ( cellN->f.dwFileAttributes & subdir ){
							if ( cmplog ){
								XMessage(NULL, NULL, XM_DbgLOG, T("not match %s"), cellN->f.cFileName);
							}
							break;
						}
						cmp_match++;
						CellMark(cinfo, cpi.in, MARK_CHECK);
						break;
					case CMP_EXIST:				// Exist(���Α� Exist)
						if ( cellN->f.dwFileAttributes & subdir ){
							if ( NO_ERROR != PPcCompareExistDirMain(
									&cpi, cinfo->RealPath,
									&cellN->f, pairpath) ){
								if ( cmplog ){
									XMessage(NULL, NULL, XM_DbgLOG, T("not match %s"), cellN->f.cFileName);
								}
								break;
							}
							MessageMatchEntry(cinfo->info.hWnd, hPairWnd,
									PairLoadCounter, cellp->f.cFileName);
						}
						cmp_match++;
						CellMark(cinfo, cpi.in, MARK_CHECK);
						break;

					case CMP_SIZE:				// small size(���Α� FileSize)
					case CMP_SIZE | CMPDOWN:	// large size(���ݑ� FileSize)
						if ( (cellN->f.nFileSizeHigh != cellp->f.nFileSizeHigh) ||
							 (cellN->f.nFileSizeLow != cellp->f.nFileSizeLow) ){
							cmp_match++;
							CellMark(cinfo, cpi.in, MARK_CHECK);
						}
						break;

					case CMP_LARGE:				// small size(���Α� FileSize)
						if ( cellN->f.nFileSizeHigh == cellp->f.nFileSizeHigh){
							if (cellN->f.nFileSizeLow < cellp->f.nFileSizeLow){
								cmp_match++;
								CellMark(cinfo, cpi.in, MARK_CHECK);
							}
						}else if (cellN->f.nFileSizeHigh < cellp->f.nFileSizeHigh){
							cmp_match++;
							CellMark(cinfo, cpi.in, MARK_CHECK);
						}
						break;
					case CMP_LARGE | CMPDOWN:	// large size(���ݑ� FileSize)
						if ( cellN->f.nFileSizeHigh == cellp->f.nFileSizeHigh){
							if (cellN->f.nFileSizeLow > cellp->f.nFileSizeLow){
								cmp_match++;
								CellMark(cinfo, cpi.in, MARK_CHECK);
							}
						}else if (cellN->f.nFileSizeHigh > cellp->f.nFileSizeHigh){
							cmp_match++;
							CellMark(cinfo, cpi.in, MARK_CHECK);
						}
						break;

					case CMP_SAMESIZETIME | CMPDOWN:	// Same(���ݑ� FileSize)
					case CMP_SAMESIZETIME:				// Same
						if ( cellN->f.dwFileAttributes & subdir ){
							if ( NO_ERROR != PPcCompareSizeTimeDirMain(
									&cpi, cinfo->RealPath,
									&cellN->f, pairpath) ){
								break;
							}
							MessageMatchEntry(cinfo->info.hWnd, hPairWnd,
									PairLoadCounter, cellp->f.cFileName);
							cmp_match++;
							CellMark(cinfo, cpi.in, MARK_CHECK);
							break;
						}
						if ( FuzzyCompareFileTime(&cellN->f.ftLastWriteTime,
								&cellp->f.ftLastWriteTime)) break;
						if ( cellN->f.nFileSizeHigh != cellp->f.nFileSizeHigh){
							break;
						}
						if ( cellN->f.nFileSizeLow != cellp->f.nFileSizeLow ){
							break;
						}
						cmp_match++;
						CellMark(cinfo, cpi.in, MARK_CHECK);
						break;

					case CMP_BINARY | CMPDOWN:	// Same Binary(���ݑ�)
					case CMP_SHA1 | CMPDOWN:	// SHA1(���ݑ�)
						// �������Ȃ�
						break;

					case CMP_SHA1:				// Same SHA-1
					case CMP_BINARY: {			// Same Binary
						ERRORCODE result;
												// SysMsg��Deleted�Ȃ̂ł���
						if ( cellp->state < ECS_NORMAL ) break;
						result = PPcCompareBinaryMain(&cpi, mode, subdir,
								&cellN->f, pairpath, &cellp->f);
						if ( result == NO_ERROR ){
							cmp_match++;
							CellMark(cinfo, cpi.in, MARK_CHECK);
							MessageMatchEntry(cinfo->info.hWnd, hPairWnd,
									PairLoadCounter, cellp->f.cFileName);
							break;
						}
						if ( (result == ERROR_INVALID_DATA) || (result == ERROR_CANCELLED) ){
							break;
						}
						cpi.in = cinfo->e.cellIMax;
						PPErrorBox(cinfo->info.hWnd, cellp->f.cFileName, result);
						break;
					}
//					default:	// �s������͏������Ȃ�
				}

				// SimpleDir �̎��́A��r�ς݂̔�r�Ώۂ�����̔�r�Ώۂ���O��
				if ( SimpleDir ){
					if ( pairbase == cellp ){ // �擪�̎�
						pairbase++;
						cells--;

						while ( cells && (pairbase->f.cFileName[0] == '\0') ){
							pairbase++;
							cells--;
						}
					}else{
						cellp->f.cFileName[0] = '\0';	// ��r�����̂ŏ���
					}
				}
				break;
			}
														// new file
			if ( (ip == 0) &&
				((mode == (CMP_NEW | CMPDOWN)) || (mode == CMP_NEWONLY) || (mode == (CMP_NEWONLY | CMPDOWN))) ){
				cmp_match++;
				CellMark(cinfo, cpi.in, MARK_CHECK);
			}
		}
	}else{ // CMP_SIZEONLY
		ENTRYINDEX ip;
		int hilight = 0;

		for ( cpi.in = 0 ; cpi.in < cinfo->e.cellIMax ; cpi.in++ ){
			ENTRYCELL *cellN, *cellp;

			cellN = &CEL(cpi.in);
			if ( cellN->state < ECS_NORMAL ) continue; // SysMsg��Deleted�͂���
			if ( cellN->attr & (ECA_PARENT | ECA_THIS) ) continue;
			if ( cellN->f.dwFileAttributes & unmarkmask ) continue;

			cmp_total++;
			cellp = pairbase;
			for ( ip = cells ; ip ; ip--, cellp++ ){
				DWORD nowtick;
														// �}�[�N�ΏۊO�����H
				if ( cellp->f.dwFileAttributes & unmarkmask ) continue;

				nowtick = GetTickCount();
				if ( (nowtick - cpi.tick) > CPI_INTERVAL ){
					cpi.tick = nowtick;
					cpi.path = cellN->f.cFileName;
					if ( IsTrue(CompareProgress(&cpi)) ) break;
				}

				if ( (cellN->f.nFileSizeHigh == cellp->f.nFileSizeHigh) &&
					 (cellN->f.nFileSizeLow  == cellp->f.nFileSizeLow) ){
					if ( cellp->f.dwFileAttributes & dirmask ){
							// ������t�@�C���ŁA�������f�B���N�g���Ȃ�ΏۊO
						if ( (cellp->f.dwFileAttributes ^ cellN->f.dwFileAttributes) &
								FILE_ATTRIBUTE_DIRECTORY ){
							continue;
						}
					}
					hilight = (hilight & 3) + 1;
					cellN->highlight = (BYTE)hilight;
					cmp_match++;
					CellMark(cinfo, cpi.in, MARK_CHECK);
					MessageMatchEntry(cinfo->info.hWnd, hPairWnd,
							PairLoadCounter, cellp->f.cFileName);
				}
			}
		}
	}
	ProcHeapFree(paircell);
	StopPopMsg(cinfo, PMF_STOP);

	PostMessage( ((mode == CMP_BINARY) || (mode == CMP_SHA1)) ?
			hPairWnd : cinfo->info.hWnd, WM_PPXCOMMAND, KC_ENDCOMPARE,
			((cmp_total != 0) && (cmp_match == cmp_total)) ? (LPARAM)-1 : (LPARAM)cmp_match);
	Repaint(cinfo);
	PPxCommonCommand(cinfo->info.hWnd, 0, K_DELETEJOBTASK);
	return NO_ERROR;
}

void PPcCompareOneWindow(PPC_APPINFO *cinfo, int mode)
{
	int i, oldmatch = -1, hilight = 0, matchpair = 0;
	XC_SORT xc = { {{0, -1, -1, -1}}, 0, SORTE_DEFAULT_VALUE};

	cinfo->MarkMask = (mode >> CMPMARKSHIFT) & CMPMARKMASK;
	mode = (mode & CMPTYPEMASK) - CMP_1SIZE;
	xc.mode.dat[0] = (char)((mode == 0) ? 2 : 17); // �������₷���悤�Ƀ\�[�g
	PPC_SortMain(cinfo, &xc);

	for ( i = 0 ; i < cinfo->e.cellIMax - 1 ; i++ ){
		if ( mode == 0 ){
			if ( (CEL(i).f.nFileSizeHigh == CEL(i + 1).f.nFileSizeHigh) &&
				 (CEL(i).f.nFileSizeLow == CEL(i + 1).f.nFileSizeLow) ){
				if ( (CEL(i).f.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) ||
					 (CEL(i+1).f.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY)){
					continue;
				}
			}else{
				continue;
			}
		}else{
			if ((CEL(i).comment != EC_NOCOMMENT) &&
				(CEL(i + 1).comment != EC_NOCOMMENT) &&
				!tstrcmp(ThPointerT(&cinfo->EntryComments, CEL(i).comment),
						 ThPointerT(&cinfo->EntryComments, CEL(i+ 1).comment))){
				// ��s
			}else{
				continue;
			}
		}
		// �Y���L��
		if ( i != oldmatch ){ // ��A��
			hilight = (hilight & 3) + 1;
			CellMark(cinfo, i, MARK_CHECK);
			CEL(i).highlight = (BYTE)hilight;
		}
		oldmatch = i + 1;
		CellMark(cinfo, i + 1 , MARK_CHECK);
		CEL(i + 1).highlight = (BYTE)hilight;
		matchpair++;
	}

	xc.mode.dat[0] = 6;					// �}�[�N�G���g�����W�߂�
	PPC_SortMain(cinfo, &xc);
	Result_Match(cinfo, matchpair);
	Repaint(cinfo);
}

DWORD CompareHashMain(PPC_APPINFO *cinfo, const TCHAR *hashtop, DWORD hashlen)
{
	ENTRYCELL *cell;
	int work;
	int match = 0;
	TCHAR *cmtptr;

	InitEnumMarkCell(cinfo, &work);
	while ( (cell = EnumMarkCell(cinfo, &work)) != NULL ){
		if ( cell->comment == EC_NOCOMMENT ) continue;
		cmtptr = ThPointerT(&cinfo->EntryComments, cell->comment);
		cmtptr = tstrchr(cmtptr, ':');
		if ( cmtptr == NULL ) continue;

		if ( !memicmp(cmtptr + 1, hashtop, hashlen * sizeof(TCHAR)) ){
			cell->highlight = 1;
			Repaint(cinfo);
			match++;
		}
	}
	return match;
}

DWORD CompareHashFromClipBoard(PPC_APPINFO *cinfo, int comparemode)
{
	TCHAR ClipBoardText[0x800], *ptr, *hashtop;
	HGLOBAL hG;
	size_t size = 0;
	int match;
	DWORD oldhashlen = 0;

	if ( OpenClipboardCheck(cinfo) == FALSE ) return 0;

#ifdef UNICODE
	hG = GetClipboardData(CF_UNICODETEXT);
#else
	hG = GetClipboardData(CF_TEXT);
#endif
	if ( hG != NULL ) {
		size = GlobalSize(hG);
		if ( size < sizeof(ClipBoardText) ){
			memcpy(ClipBoardText, GlobalLock(hG), size);
			ClipBoardText[size / sizeof(TCHAR)] = '\0';
		}
	}
	CloseClipboard();
	if ( size == 0 ) return 0;

	match = 0;
	for ( ptr = ClipBoardText; ; ptr++ ){ // �e�L�X�g���̃n�b�V����T��
		TCHAR c, *type;
		DWORD hashlen;

		c = *ptr;
		if ( c == '\0' ) break;
		if ( !Isxdigit(c) ) continue;
		hashtop = ptr++;
		hashlen = 1;
		for ( ;; ){ // 16�i������̒��������߂�
			c = *ptr;
			if ( !Isxdigit(c) ) break;
			ptr++;
			hashlen++;
		}
		switch (hashlen){
			case 8:
				type = T("crc32");
				break;

			case 32:
				type = T("md5");
				break;

			case 40:
				type = T("sha1");
				break;

			case 56:
				type = T("sha224");
				break;

			case 64:
				type = T("sha256");
				break;

			default: // �Y��������̂���������
				continue;
		}
		if ( comparemode ){ // �e�G���g���Ɣ�r
			if ( hashlen != oldhashlen ){
				if ( CommentCommand(cinfo, type) != NO_ERROR ) return 0;
				oldhashlen = hashlen;
			}
			match += CompareHashMain(cinfo, hashtop, hashlen);
		}else{ // �n�b�V�����o�̂�
			return hashlen;
		}
	}
	if ( comparemode ) Result_Match(cinfo, match);
	return 0;
}

//--------------------------------------------------------------- �����I��&����
ERRORCODE PPcCompare(PPC_APPINFO *cinfo, int mode)
{
	HWND hPairWnd;
	int mode_type;

	hPairWnd = GetPairWnd(cinfo);
	if ( (mode & CMPTYPEMASK) == 0 ){ // ���@�w�薳���c���j���[�I��
		HMENU hMenu;

		hMenu = CreatePopupMenu();
		if ( hPairWnd ){
			COMPAREMENUSTRUCT *cm;

			for ( cm = CompareMenu ; cm->mode ; cm++ ){
				if ( cm->mode & CMPWITHOUT_EXT ){
					AppendMenu(hMenu, MF_SEPARATOR, 0, NULL);
				}
				AppendMenuString(hMenu, cm->mode, cm->name);
			}
			AppendMenu(hMenu, MF_SEPARATOR, 0, NULL);
		}
		AppendMenuString(hMenu, CMP_1SIZE, MES_CMPZ);
		AppendMenuString(hMenu, CMP_1COMMENT, MES_CMPM);
		AppendMenu(hMenu,
				(CompareHashFromClipBoard(cinfo, 0) != 0) ? MF_ES : MF_GS,
				CMP_1HASH, MessageText(StrMesCMPH));
		AppendMenu(hMenu, MF_SEPARATOR, 0, NULL);
		AppendMenuString(hMenu, CMP_DETAIL, MES_CMPD);
		mode = PPcTrackPopupMenu(cinfo, hMenu);
		DestroyMenu(hMenu);
	}
	mode_type = mode & CMPTYPEMASK;
	if ( mode_type == CMP_DETAIL ){
		mode = CompareDetailDialog(cinfo->info.hWnd, hPairWnd);
		if ( mode < 0 ) mode = 0;
		mode_type = mode & CMPTYPEMASK;
	}else if ( mode ){
		if ( !(mode & (CMPMARKMASK << CMPMARKSHIFT)) ) mode |= 0x700; // �����␳
	}
	if ( mode_type == CMP_1HASH ){
		CompareHashFromClipBoard(cinfo, 1);
		return NO_ERROR;
	}
	if ( mode_type >= CMP_2WINDOW ){
		COMPAREMARKPACKET cmp;

		if ( hPairWnd == NULL ) return ERROR_CANCELLED;
		if ( (mode_type == CMP_BINARY) || (mode_type == CMP_SHA1) ){
			SetPopMsg(cinfo, POPMSG_PROGRESSBUSYMSG, MES_SCMP);
		}
		cmp.mode = mode;
		MakeTempEntry(MAX_PATH, cmp.filename, FILE_ATTRIBUTE_NORMAL);
		PPcCompareSend(cinfo, &cmp, hPairWnd);
		return NO_ERROR;
	}
	if ( mode_type >= CMP_1WINDOW ){
		PPcCompareOneWindow(cinfo, mode);
		return NO_ERROR;
	}
	return ERROR_CANCELLED;
}

int GetCMarkMode(HWND hDlg)
{
	int mode = (int)SendMessage(hDlg, CB_GETCURSEL, 0, 0);

	if ( mode >= 0 ) mode = (int)SendMessage(hDlg, CB_GETITEMDATA, (WPARAM)mode ,0);
	return mode;
}

int GetCMarkSettings(HWND hDlg)
{
	int mode = GetCMarkMode(GetDlgItem(hDlg, IDC_TYPE));

	mode |= (GetAttibuteSettings(hDlg) << CMPMARKSHIFT) |
		(IsDlgButtonChecked(hDlg, IDX_WHERE_SDIR) ?
				(CMPSUBDIR | (FILE_ATTRIBUTE_DIRECTORY << CMPMARKSHIFT)) : 0);
	return mode;
}

//  --------------------------------------------------------------
INT_PTR CALLBACK CompareDetailDlgBox(HWND hDlg, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
	switch(iMsg){
		case WM_INITDIALOG: {
			int index = 0;

			CenterWindow(hDlg);
			LocalizeDialogText(hDlg, IDD_CMARK);
			SetWindowLongPtr(hDlg, DWLP_USER, (LONG_PTR)lParam);

			if ( (HWND)lParam == NULL ){ // ���΂Ȃ��H���Q���n���X�L�b�v
				index = CMP2TYPES;
			}

			for ( ; index < DETAILMENU_ITEMS ; index++ ){
				int id;

				id = SendDlgItemMessage(hDlg, IDC_TYPE,
						CB_ADDSTRING, 0, (LPARAM)MessageText(CompareDetailMenu[index]) );
				SendDlgItemMessage(hDlg, IDC_TYPE, CB_SETITEMDATA, (WPARAM)id, (LPARAM)CompareDetailIndex[index]);
			}

			{ // if ( CompareHashFromClipBoard(cinfo, 0) != 0)
				int id;

				id = SendDlgItemMessage(hDlg, IDC_TYPE,
						CB_ADDSTRING, 0, (LPARAM)MessageText(StrMesCMPH) );
				SendDlgItemMessage(hDlg, IDC_TYPE, CB_SETITEMDATA, (WPARAM)id, (LPARAM)CMP_1HASH);
			}

			SendDlgItemMessage(hDlg, IDC_TYPE, CB_SETCURSEL, 0, 0);
			SetAttibuteSettings(hDlg, FILE_ATTRIBUTE_READONLY | FILE_ATTRIBUTE_HIDDEN | FILE_ATTRIBUTE_SYSTEM | FILE_ATTRIBUTE_ARCHIVE);
			EnableDlgWindow(hDlg, IDX_WHERE_SDIR, 0);
			ActionInfo(hDlg, NULL, AJI_SHOW, T("compare"));
			return TRUE;
		}
		case WM_COMMAND:
			switch ( LOWORD(wParam) ){
				case IDOK:
					EndDialog(hDlg, GetCMarkSettings(hDlg));
					break;

				case IDCANCEL:
					EndDialog(hDlg, 0);
					break;

				case IDC_TYPE:
					if ( HIWORD(wParam) == CBN_SELCHANGE ){
						int mode = GetCMarkMode((HWND)lParam);
						EnableDlgWindow(hDlg, IDX_WHERE_SDIR,
								(mode == CMP_EXIST) ||
								(mode == CMP_SAMESIZETIME) ||
								(mode == CMP_BINARY) ||
								(mode == CMP_SHA1)
						);
						// EnableDlgWindow �̒���́AWM_PAINT �̃I�[�o���C�g�������Ȃ�����
						if ( X_uxt[0] >= UXT_MINMODIFY ) InvalidateRect(hDlg, NULL, TRUE);
					}
					break;

//				case IDB_SAVE:
//					SaveSortSettings(hDlg);
//					break;
			}
			break;

		default:
			return PPxDialogHelper(hDlg, iMsg, wParam, lParam);
	}
	return TRUE;
}

ERRORCODE CompareMarkEntry(PPC_APPINFO *cinfo, const TCHAR *param)
{
	int mode;
	int attr;

	mode = GetIntNumber(&param); // ���[�h
	NextParameter(&param);
	attr = GetDwordNumber(&param); // ����
	if ( attr <= 0 ) attr = 0x17;
	NextParameter(&param);
	if ( GetNumber(&param) ){
		if ( !( (mode == CMP_EXIST) ||
				(mode == CMP_SAMESIZETIME) ||
				(mode == CMP_BINARY) ||
				(mode == CMP_SHA1) ) ){
			SetPopMsg(cinfo, POPMSG_MSG, T("bad subdir mode"));
			return ERROR_INVALID_PARAMETER;
		}
		setflag(mode, CMPSUBDIR);
	}
	return PPcCompare(cinfo, mode | (attr << 8) | CMPWAIT);
}
