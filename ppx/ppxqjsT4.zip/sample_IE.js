﻿//!*script
// JScript / JScript(Chakra) / V8 / QuickJS 兼用
// ※イベントは V8 が未対応

PPx.report(
	"\r\n● " + PPx.ScriptName + "\r\n"+
	"Script Engine: " + PPx.ScriptEngineName + "/" + PPx.ScriptEngineVersion + "\r\n");

var IE = PPx.CreateObject("InternetExplorer.Application", "ie_");
try {
	IE._("trace"); // QuickJS のみ。イベントが発生したら全て PPx.report で通知
} catch(e) {};
IE.Visible = true;
IE.Navigate("http://toro.d.dooo.jp/");

function ie_DownloadComplete(sender, e){
	PPx.report("<<load Complete>>");
}
function ie_OnVisible(sender, e){
	PPx.report("<<show>>");
}
