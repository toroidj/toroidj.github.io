//!*script
// QuickJS / V8 用
// QuickJS の場合、*scriptm のみ静的import対応。また、エラー・例外が返されず、
// 組み込みエラー通知が効かない為、try - cache で自前のエラー処理が必要。
import * as exmodule from "./sample_export.js";
try {
	import('./sample_export.js').then(module => {
		PPx.report("dynamic 10 * 123 = " + module.test(10));
	});

	PPx.report("static 10 * 123 = " + exmodule.test(10));
}catch(e){
	PPx.Echo("-- PPxQjs.dll error --\n" + PPx.ScriptName + "\n" + e + "\n" + e.stack);
}
